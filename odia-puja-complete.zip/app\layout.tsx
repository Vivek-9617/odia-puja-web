import type { Metadata } from 'next';
import './globals.css';
import { AuthProvider } from '@/context/AuthContext';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import AuthModal from '@/components/AuthModal';

export const metadata: Metadata = {
  title: 'OdiaPuja: Odisha Pandit & Puja Booking Platform | ଓଡ଼ିଆ ପୂଜା',
  description:
    'Odisha&apos;s #1 authentic Vedic Purohit and Puja booking platform. Book verified pandits in Bhubaneswar, Puri, Cuttack, and all 30 districts for Satyanarayana Vrata, Griha Pravesh, and Havan.',
  keywords: [
    'Odia Puja',
    'Odisha Pandit Booking',
    'Bhubaneswar Purohit',
    'Puri Jagannath Puja',
    'Griha Pravesh Odisha',
    'Satyanarayana Puja Odia',
    'Manabasa Gurubara',
  ],
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="or-IN" className="h-full antialiased scroll-smooth">
      <body className="min-h-full flex flex-col bg-stone-50 text-stone-900 font-sans selection:bg-orange-500 selection:text-white">
        <AuthProvider>
          <Header />
          <div className="flex-1">{children}</div>
          <Footer />
          <AuthModal />
        </AuthProvider>
      </body>
    </html>
  );
}
