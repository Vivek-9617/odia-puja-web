import { PanditProfile, Puja } from '@/types/database';

export const FALLBACK_PUJAS: Puja[] = [
  {
    id: '30a685d2-7027-491e-a169-631a04c54316',
    name_odia: 'ଜଗନ୍ନାଥ ପୂଜା ଓ ତୁଳସୀ ହବନ',
    name_english: 'Jagannath Puja & Tulasi Havan',
    category: 'Odisha Special',
    description: 'Traditional Utkaliya rituals dedicated to Mahaprabhu Jagannath with 108 Tulasi Arpana, Gita Patha, and sacred Utkal Parampara Havan.',
    duration_hours: 3.0,
    base_dakshina: 2501,
    samagri_list: [
      { item: 'Tulasi Leaves (Manjari)', qty: '108 pcs' },
      { item: 'Pure Desi Cow Ghee', qty: '500 gm' },
      { item: 'Malayagiri Chandan', qty: '50 gm' },
      { item: 'Puri Sri Mandir Nirmalya', qty: '1 packet' },
      { item: 'Dry Fruits & Mahaprasad Khaja', qty: '250 gm' },
      { item: 'Panchamrita & Honey', qty: '1 pot' }
    ],
    image_url: 'https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/Shri_Jagannatha_Temple.jpg/800px-Shri_Jagannatha_Temple.jpg',
    is_active: true
  },
  {
    id: 'c2a92738-2924-40ae-9da5-e187cf040840',
    name_odia: 'ମାଣବସା ଗୁରୁବାର ପୂଜା',
    name_english: 'Manabasa Gurubara Lakshmi Puja',
    category: 'Odisha Special',
    description: 'Sacred Margashirsha Thursday ritual dedicated to Maa Mahalaxmi with traditional Mana filling of freshly harvested paddy grains and Lakshmi Purana recitation.',
    duration_hours: 2.5,
    base_dakshina: 1501,
    samagri_list: [
      { item: 'New Bamboo Mana (ବେତ ମାଣ)', qty: '1 pc' },
      { item: 'Fresh Golden Paddy Grains (ଧାନ)', qty: '1.5 kg' },
      { item: 'Arua Rice paste for traditional Jhoti Chita', qty: '250 gm' },
      { item: 'Red Silken Pata Cloth for Maa', qty: '1 meter' },
      { item: 'White flowers (Mandar, Malli, Juhi)', qty: '2 malas' },
      { item: 'Steamed Manda Pitha & Khiri', qty: 'Prasad' }
    ],
    image_url: 'https://images.unsplash.com/photo-1512413914633-b5043f4041ea?auto=format&fit=crop&w=800&q=80',
    is_active: true
  },
  {
    id: 'ec99e488-30f5-4f27-8293-d36b449eb0e8',
    name_odia: 'ନୂତନ ଗୃହ ପ୍ରବେଶ ଓ ବାସ୍ତୁ ଶାନ୍ତି',
    name_english: 'Griha Pravesh & Vastu Shanti',
    category: 'Griha Pravesh',
    description: 'Complete new home sanctification with Vastu Purusha Sthapana, Navagraha Homa, milk-overflow ritual (Kshira Uturaiba), and Kuladevata invocation.',
    duration_hours: 4.5,
    base_dakshina: 5101,
    samagri_list: [
      { item: 'Heavy Brass / Copper Kalash', qty: '2 pcs' },
      { item: 'Navadhanya (9 sacred grains)', qty: '500 gm' },
      { item: 'Sacred Havan Mango Wood & Khaira', qty: '3 kg' },
      { item: 'Pure Cow Milk & Clay Handi for boiling', qty: '1 set' },
      { item: 'Ash Gourd / Pani Kakharu for Vastu Bali', qty: '1 whole' },
      { item: 'Gau Mutra, Gangajal & Panchagavya', qty: '1 set' }
    ],
    image_url: 'https://images.unsplash.com/photo-1545232979-8bf68ee9b1af?auto=format&fit=crop&w=800&q=80',
    is_active: true
  },
  {
    id: '4452a831-5f21-4123-bc90-e516312adbc1',
    name_odia: 'ଶ୍ରୀ ସତ୍ୟନାରାୟଣ ପୂଜା',
    name_english: 'Sri Satyanarayana Puja',
    category: 'Odisha Special',
    description: 'Auspicious Lord Vishnu blessing ritual performed on Purnima, Sankranti, or family milestones with authentic Sirini prasad preparation and 5-chapter Katha.',
    duration_hours: 2.5,
    base_dakshina: 1501,
    samagri_list: [
      { item: 'Arua Rice (Raw Rice)', qty: '1 kg' },
      { item: 'Champa Kadali (Bananas)', qty: '1 dozen' },
      { item: 'Wheat Flour / Atta & Sugar for Sirini', qty: '500 gm' },
      { item: 'Pure Cow Ghee', qty: '250 gm' },
      { item: 'Betel leaves (Pana) & Supari (Gua)', qty: '10 pairs' },
      { item: 'Tulasi leaves & Marigold Flowers', qty: '1 basket' }
    ],
    image_url: 'https://images.unsplash.com/photo-1605371924599-2d0365da1ae0?auto=format&fit=crop&w=800&q=80',
    is_active: true
  },
  {
    id: 'f87a8291-7643-41bb-a5a1-791823abce12',
    name_odia: 'ମହା ରୁଦ୍ରାଭିଷେକ ଓ ଶିବ ଆରାଧନା',
    name_english: 'Maha Rudrabhishek & Shiva Puja',
    category: 'Odisha Special',
    description: 'Vedic Rudra Abhishek with 11 Dravyas, 108 Bael leaves, Chamakam, Namakam and Maha Mrityunjaya Japa for health and removal of planetary distress.',
    duration_hours: 3.0,
    base_dakshina: 2101,
    samagri_list: [
      { item: 'Fresh Belapatra (Triple leaf)', qty: '108 pcs' },
      { item: 'Raw Cow Milk & Curd', qty: '1.5 Litres' },
      { item: 'Sugarcane Juice & Honey', qty: '500 ml' },
      { item: 'Gangajal & Bhasma (Bibhuti)', qty: '1 kit' },
      { item: 'Dhatura Flowers & Fruits', qty: '5 pcs' }
    ],
    image_url: 'https://upload.wikimedia.org/wikipedia/commons/thumb/2/23/A_river_and_decorated_Shiva_linga_pooja%2C_Hindu_rituals.jpg/800px-A_river_and_decorated_Shiva_linga_pooja%2C_Hindu_rituals.jpg',
    is_active: true
  },
  {
    id: 'b1274c39-4411-4091-a128-4981dbe59821',
    name_odia: 'ମା\' ସରସ୍ୱତୀ ପୂଜା ଓ ଖଡ଼ିଛୁଆଁ',
    name_english: 'Saraswati Puja & Vidya Arambha',
    category: 'Festivals',
    description: 'Basanta Panchami invocation for Goddess Saraswati. Includes sacred Khadi Chhuan (slate & chalk initiation) for young children embarking on education.',
    duration_hours: 2.0,
    base_dakshina: 1101,
    samagri_list: [
      { item: 'Yellow / White Marigold Garlands', qty: '2 malas' },
      { item: 'Traditional Slate & Chalk (Khadi)', qty: '1 set' },
      { item: 'Sweet Ber fruit, Bananas & Seasonal fruits', qty: '1 basket' },
      { item: 'Yellow Boondi & Panchamrita', qty: '500 gm' },
      { item: 'Incense sticks, Kapoor & Sandalwood', qty: '1 set' }
    ],
    image_url: 'https://upload.wikimedia.org/wikipedia/commons/thumb/a/a2/Saraswati_murti.jpg/800px-Saraswati_murti.jpg',
    is_active: true
  },
  {
    id: 'e100f931-1928-4091-b384-998124baca90',
    name_odia: 'ସୁଦଶା ବ୍ରତ ପୂଜା',
    name_english: 'Sudasha Brata Lakshmi Puja',
    category: 'Odisha Special',
    description: 'Iconic Odia vrata observed on Shukla Paksha Dasami falling on a Thursday. Features 10-knot consecrated holy thread and 10 varieties of Odia offerings.',
    duration_hours: 2.5,
    base_dakshina: 1251,
    samagri_list: [
      { item: '10-knot consecrated thread (Dasa Ganthia Dora)', qty: '2 pcs' },
      { item: '10 varieties of seasonal Odia blossoms', qty: '10 types' },
      { item: '10 steamed Manda Pithas / Chenagaja', qty: '10 pcs' },
      { item: 'Betel leaves and betel nuts', qty: '10 pairs' },
      { item: 'Water coconut with intact stalk', qty: '1 pc' }
    ],
    image_url: 'https://images.unsplash.com/photo-1605371924599-2d0365da1ae0?auto=format&fit=crop&w=800&q=80',
    is_active: true
  },
  {
    id: 'a9104812-7811-411a-ba22-817290abce45',
    name_odia: 'ମା\' ଦୁର୍ଗା ପୂଜା ଓ ଚଣ୍ଡୀ ହୋମ',
    name_english: 'Maa Durga Puja & Chandi Homa',
    category: 'Festivals',
    description: 'Fervent Vedic Shakti invocation with Devi Saptashati Parayana, Navarna Mantra Japa, and Maha Purnahuti Homa for peace, victory, and protection.',
    duration_hours: 4.0,
    base_dakshina: 4501,
    samagri_list: [
      { item: 'Silken Red Chunari & Mata Shringar Kit', qty: '1 set' },
      { item: 'Havan Samagri with Desi Ghee', qty: '2 kg' },
      { item: 'Dry Fruits, Makhana & Panchameva', qty: '300 gm' },
      { item: 'Shriphal Coconuts', qty: '3 pcs' },
      { item: 'Kumkum, Sandalwood & Sacred Thread', qty: '1 kit' }
    ],
    image_url: 'https://upload.wikimedia.org/wikipedia/commons/thumb/c/cf/Maa_Durga.jpg/800px-Maa_Durga.jpg',
    is_active: true
  },
  {
    id: 'c9981245-8123-41bb-a128-487192abce99',
    name_odia: 'ନୂତନ ପ୍ରତିଷ୍ଠାନ ଓ କାର୍ଯ୍ୟାଳୟ ପ୍ରବେଶ',
    name_english: 'Office & Business Vastu Puja',
    category: 'Griha Pravesh',
    description: 'Ganesh-MahaLakshmi-Kuber Sthapana, commercial Vastu purification, and doorway Torana sanctification for business prosperity and financial growth.',
    duration_hours: 3.0,
    base_dakshina: 3101,
    samagri_list: [
      { item: 'Copper Kalash with green mango twigs', qty: '2 sets' },
      { item: 'Kuber / Shree Yantra with silver coin', qty: '1 pc' },
      { item: 'Navadhanya and Yellow Cloth', qty: '500 gm' },
      { item: 'Motichoor Laddus & Fresh Fruits', qty: '1.5 kg' },
      { item: 'Fresh Marigold / Mango Leaf Entrance Toran', qty: '2 malas' }
    ],
    image_url: 'https://images.unsplash.com/photo-1567157577867-05ccb1388e66?auto=format&fit=crop&w=800&q=80',
    is_active: true
  }
];

export const CURATED_PANDITS: PanditProfile[] = [
  {
    id: '1403b388-9d20-48ae-aced-8b8c05b1d967',
    district: 'Khordha (Bhubaneswar)',
    city_town: 'Saheed Nagar, Bhubaneswar',
    vedic_qualification: 'Veda Shastri (Utkal Sanskrit University)',
    experience_years: 18,
    languages_spoken: ['Odia', 'Sanskrit', 'Hindi'],
    bio: 'Specialist in Sri Satyanarayana Vrata, Griha Pravesh & Navagraha Shanti Havan with 18 years of authentic Utkaliya Vedic Karma Kanda practice.',
    is_verified: true,
    is_available: true,
    rating: 4.9,
    profiles: {
      full_name: 'Pandit Bhabani Shankar Dash',
      phone: '9437128910',
      role: 'pandit'
    }
  },
  {
    id: 'p-puri-001',
    district: 'Puri',
    city_town: 'Badadanda, Near Jagannath Temple, Puri',
    vedic_qualification: 'Smarta Acharya (Mukti Mandap Affiliated, Puri)',
    experience_years: 25,
    languages_spoken: ['Odia', 'Sanskrit'],
    bio: 'Renowned Mukti Mandap affiliated sevayat specialist in Lord Jagannath puja, Sudasha Brata, and sacred Utkal Shradha rituals.',
    is_verified: true,
    is_available: true,
    rating: 5.0,
    profiles: {
      full_name: 'Pandit Krushna Chandra Mishra',
      phone: '9861044521',
      role: 'pandit'
    }
  },
  {
    id: 'p-ctc-002',
    district: 'Cuttack',
    city_town: 'CDA Sector 9, Cuttack',
    vedic_qualification: 'Rigveda Acharya & Karmakand Specialist',
    experience_years: 14,
    languages_spoken: ['Odia', 'Sanskrit', 'English'],
    bio: 'Expert in Griha Pravesh, Vastu Havan, and Chandi Patha with detailed meaning explanations in Odia and English for modern families.',
    is_verified: true,
    is_available: true,
    rating: 4.8,
    profiles: {
      full_name: 'Pandit Debabrata Panigrahi',
      phone: '9437288123',
      role: 'pandit'
    }
  },
  {
    id: 'p-gan-003',
    district: 'Ganjam',
    city_town: 'Hillpatna, Berhampur',
    vedic_qualification: 'Jyotirvid & Yajurveda Purohit',
    experience_years: 15,
    languages_spoken: ['Odia', 'Telugu', 'Hindi'],
    bio: 'Vedic practitioner specializing in Maha Rudrabhishek, Mahamrityunjaya Japa, and marriage sanskaras across South Odisha.',
    is_verified: true,
    is_available: true,
    rating: 4.9,
    profiles: {
      full_name: 'Pandit Sudhanshu Sekhar Rath',
      phone: '9937012345',
      role: 'pandit'
    }
  },
  {
    id: 'p-sam-004',
    district: 'Sambalpur',
    city_town: 'Budharaja, Sambalpur',
    vedic_qualification: 'Karma Kanda Shastri (Gangadhar Meher)',
    experience_years: 20,
    languages_spoken: ['Odia', 'Sambalpuri', 'Hindi'],
    bio: 'Experienced Purohit dedicated to Western Odisha festive pujas, Nuakhai rituals, Lakshmi Puja, and Vastu purification.',
    is_verified: true,
    is_available: true,
    rating: 4.8,
    profiles: {
      full_name: 'Pandit Narayan Panda',
      phone: '9853299014',
      role: 'pandit'
    }
  },
  {
    id: 'p-bal-005',
    district: 'Balasore',
    city_town: 'Remuna, Balasore',
    vedic_qualification: 'Acharya in Jyotisha & Purohitya',
    experience_years: 12,
    languages_spoken: ['Odia', 'Bengali', 'Hindi'],
    bio: 'Proficient in Khirachora Gopinath tradition pujas, Navagraha homa, and Ekousia (21st-day newborn sanskara).',
    is_verified: true,
    is_available: true,
    rating: 4.7,
    profiles: {
      full_name: 'Pandit Ashish Kumar Tripathy',
      phone: '9777123987',
      role: 'pandit'
    }
  }
];
