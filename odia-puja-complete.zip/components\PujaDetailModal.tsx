'use client';

import React, { useState } from 'react';
import { Puja, MUHURAT_SLOTS, ODISHA_DISTRICTS, OdishaDistrict } from '@/types/database';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/supabase';
import {
  X,
  Clock,
  Printer,
  CheckSquare,
  Square,
  Calendar,
  MapPin,
  Phone,
  User,
  CheckCircle2,
  AlertCircle,
  PackageCheck,
  Flame,
  ArrowRight
} from 'lucide-react';

interface PujaDetailModalProps {
  puja: Puja | null;
  isOpen: boolean;
  onClose: () => void;
  onBookingSuccess?: () => void;
}

export default function PujaDetailModal({
  puja,
  isOpen,
  onClose,
  onBookingSuccess,
}: PujaDetailModalProps) {
  const { user, profile, selectedDistrict, openAuthModal } = useAuth();

  // Booking Form State
  const [bookingDate, setBookingDate] = useState('2026-11-07');
  const [bookingTime, setBookingTime] = useState(MUHURAT_SLOTS[1].time);
  const [district, setDistrict] = useState<OdishaDistrict>(selectedDistrict);
  const [address, setAddress] = useState('');
  const [userName, setUserName] = useState(() => profile?.full_name || '');
  const [userPhone, setUserPhone] = useState(() => profile?.phone || '');
  const [includeSamagri, setIncludeSamagri] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [bookingError, setBookingError] = useState('');
  const [confirmedBookingId, setConfirmedBookingId] = useState<string | null>(null);

  // Samagri Checklist State (checked indices)
  const [checkedSamagri, setCheckedSamagri] = useState<Record<number, boolean>>({});

  // Tab on mobile or desktop view
  const [activeTab, setActiveTab] = useState<'details' | 'booking'>('details');

  if (!isOpen || !puja) return null;

  const SAMAGRI_KIT_PRICE = 750;
  const baseDakshina = puja.base_dakshina || 1501;
  const totalDakshina = includeSamagri ? baseDakshina + SAMAGRI_KIT_PRICE : baseDakshina;

  const toggleSamagriItem = (index: number) => {
    setCheckedSamagri((prev) => ({
      ...prev,
      [index]: !prev[index],
    }));
  };

  const handlePrintSamagri = () => {
    const printWindow = window.open('', '_blank', 'width=700,height=800');
    if (!printWindow) {
      alert('Please allow popups to print the samagri list.');
      return;
    }

    const itemsHtml = (puja.samagri_list || [])
      .map(
        (item, i) => `
        <tr style="border-bottom: 1px solid #e5e7eb;">
          <td style="padding: 10px 12px; font-size: 14px; color: #4b5563;">${i + 1}. [ &nbsp; ]</td>
          <td style="padding: 10px 12px; font-size: 15px; font-weight: 600; color: #1f2937;">${item.item}</td>
          <td style="padding: 10px 12px; font-size: 14px; text-align: right; color: #c2410c; font-weight: bold;">${item.qty}</td>
        </tr>
      `
      )
      .join('');

    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
      <head>
        <title>${puja.name_english} - Samagri Checklist | OdiaPuja</title>
        <style>
          body { font-family: system-ui, -apple-system, sans-serif; padding: 30px; color: #1c1917; }
          .header { border-bottom: 2px solid #ea580c; padding-bottom: 15px; margin-bottom: 20px; }
          .title { font-size: 24px; font-weight: bold; color: #9a3412; }
          .subtitle { font-size: 18px; color: #ea580c; margin-top: 4px; }
          .meta { font-size: 13px; color: #6b7280; margin-top: 8px; }
          table { width: 100%; border-collapse: collapse; margin-top: 15px; }
          th { text-align: left; padding: 10px 12px; background: #fff7ed; border-bottom: 2px solid #fdba74; color: #9a3412; font-size: 13px; text-transform: uppercase; }
          .footer { margin-top: 35px; border-top: 1px dashed #d1d5db; padding-top: 15px; font-size: 12px; color: #6b7280; text-align: center; }
        </style>
      </head>
      <body>
        <div class="header">
          <div style="font-size: 12px; color: #ea580c; font-weight: bold; text-transform: uppercase;">ଜୟ ଜଗନ୍ନାଥ • OdiaPuja Platform</div>
          <div class="title">${puja.name_english}</div>
          <div class="subtitle">${puja.name_odia}</div>
          <div class="meta">Duration: ${puja.duration_hours} Hours | Dakshina: ₹${puja.base_dakshina} | Platform Verified Samagri List</div>
        </div>

        <p style="font-size: 14px; line-height: 1.5; color: #44403c;">${puja.description}</p>

        <h3 style="color: #9a3412; margin-top: 25px; border-left: 4px solid #ea580c; padding-left: 8px;">Auspicious Samagri Required (ପୂଜା ସାମଗ୍ରୀ ତାଲିକା):</h3>
        <table>
          <thead>
            <tr>
              <th style="width: 70px;">Tick</th>
              <th>Sacred Samagri Item</th>
              <th style="text-align: right;">Quantity</th>
            </tr>
          </thead>
          <tbody>
            ${itemsHtml}
          </tbody>
        </table>

        <div class="footer">
          Printed from <strong>OdiaPuja: Odisha Pandit & Puja Booking Platform</strong> • Helpline / Support: +91 98610 12345
        </div>
        <script>
          window.onload = function() { window.print(); }
        </script>
      </body>
      </html>
    `);
    printWindow.document.close();
  };

  const handleBookingSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBookingError('');

    // Check if user is logged in
    if (!user && !profile) {
      openAuthModal('login');
      return;
    }

    const currentName = userName.trim() || profile?.full_name || '';
    const currentPhone = userPhone.trim() || profile?.phone || '';

    if (!currentName || !currentPhone || !address.trim() || !bookingDate) {
      setBookingError('Please fill in your name, contact phone, date, and address.');
      return;
    }

    setIsSubmitting(true);

    try {
      const payload = {
        user_id: user?.id || null,
        puja_id: puja.id,
        booking_date: bookingDate,
        booking_time: bookingTime,
        user_name: currentName,
        user_phone: currentPhone,
        user_address: address.trim(),
        district: district,
        include_samagri: includeSamagri,
        total_amount: totalDakshina,
        status: 'pending',
      };

      const { data, error } = await supabase
        .from('bookings')
        .insert([payload])
        .select();

      if (error) {
        throw error;
      }

      const newId = data?.[0]?.id || `ODP-${Math.floor(100000 + Math.random() * 900000)}`;
      setConfirmedBookingId(newId);

      if (onBookingSuccess) {
        onBookingSuccess();
      }
    } catch (err: unknown) {
      setBookingError((err as Error).message || 'Failed to submit booking. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const totalSamagriCount = puja.samagri_list?.length || 0;
  const checkedCount = Object.values(checkedSamagri).filter(Boolean).length;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 md:p-6 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200 overflow-y-auto">
      <div
        className="relative w-full max-w-4xl bg-white rounded-2xl shadow-2xl border border-orange-200 overflow-hidden my-auto max-h-[92vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="bg-gradient-to-r from-orange-600 via-amber-600 to-red-700 text-white p-4 md:p-6 relative shrink-0">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 text-white/80 hover:text-white bg-black/20 hover:bg-black/40 rounded-full p-2 transition"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex flex-wrap items-center gap-2 mb-2">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-white/20 text-white backdrop-blur-xs">
              {puja.category}
            </span>
            <span className="flex items-center gap-1 text-xs text-orange-100 bg-black/20 px-2 py-0.5 rounded-full">
              <Clock className="w-3.5 h-3.5" />
              {puja.duration_hours} Hours Ritual
            </span>
            <span className="text-xs bg-amber-400 text-amber-950 font-bold px-2 py-0.5 rounded-full">
              Dakshina: ₹{puja.base_dakshina.toLocaleString('en-IN')}
            </span>
          </div>

          <h2 className="text-xl md:text-3xl font-bold font-serif text-white tracking-wide">
            {puja.name_english}
          </h2>
          <p className="text-base md:text-lg text-amber-200 font-semibold font-serif mt-0.5">
            {puja.name_odia}
          </p>
        </div>

        {/* Tab switcher on Mobile */}
        <div className="md:hidden flex border-b border-orange-100 bg-orange-50/70 shrink-0">
          <button
            onClick={() => setActiveTab('details')}
            className={`flex-1 py-2.5 text-xs font-bold transition ${
              activeTab === 'details'
                ? 'text-orange-700 border-b-2 border-orange-600 bg-white'
                : 'text-stone-600'
            }`}
          >
            Ritual & Samagri ({checkedCount}/{totalSamagriCount})
          </button>
          <button
            onClick={() => setActiveTab('booking')}
            className={`flex-1 py-2.5 text-xs font-bold transition ${
              activeTab === 'booking'
                ? 'text-orange-700 border-b-2 border-orange-600 bg-white'
                : 'text-stone-600'
            }`}
          >
            Book Pandit (₹{totalDakshina.toLocaleString('en-IN')})
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-4 md:p-6 grid grid-cols-1 md:grid-cols-12 gap-6">
          {/* Left Column: Ritual Details & Interactive Samagri Checklist */}
          <div
            className={`md:col-span-7 space-y-6 ${
              activeTab === 'details' ? 'block' : 'hidden md:block'
            }`}
          >
            {/* Description Banner */}
            <div className="bg-orange-50/80 rounded-xl p-4 border border-orange-200">
              <div className="flex items-center gap-2 text-orange-900 font-bold text-sm mb-1.5">
                <Flame className="w-4 h-4 text-orange-600" />
                <span>Vedic Ritual Significance (ପୂଜାର ମାହାତ୍ମ୍ୟ)</span>
              </div>
              <p className="text-sm text-stone-700 leading-relaxed">
                {puja.description}
              </p>
            </div>

            {/* Samagri Checklist */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <div>
                  <h3 className="text-base font-bold text-stone-900 flex items-center gap-2">
                    <span>Auspicious Samagri Checklist</span>
                    <span className="text-xs bg-orange-100 text-orange-800 px-2 py-0.5 rounded-full font-medium">
                      {checkedCount} of {totalSamagriCount} Ready
                    </span>
                  </h3>
                  <p className="text-xs text-stone-500">
                    Tick items as you arrange them, or select &ldquo;Bring Complete Samagri Kit&rdquo; below.
                  </p>
                </div>

                <button
                  type="button"
                  onClick={handlePrintSamagri}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-lg text-xs font-semibold transition border border-stone-300 shadow-xs"
                >
                  <Printer className="w-3.5 h-3.5 text-orange-600" />
                  <span>Print List</span>
                </button>
              </div>

              {/* Progress bar */}
              <div className="w-full bg-stone-100 rounded-full h-1.5 mb-3 overflow-hidden">
                <div
                  className="bg-orange-600 h-1.5 rounded-full transition-all duration-300"
                  style={{
                    width: `${totalSamagriCount ? (checkedCount / totalSamagriCount) * 100 : 0}%`,
                  }}
                />
              </div>

              <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
                {(puja.samagri_list || []).map((item, index) => {
                  const isChecked = !!checkedSamagri[index];
                  return (
                    <div
                      key={index}
                      onClick={() => toggleSamagriItem(index)}
                      className={`flex items-center justify-between p-2.5 rounded-lg border text-sm cursor-pointer transition select-none ${
                        isChecked
                          ? 'bg-emerald-50/60 border-emerald-300 text-stone-800'
                          : 'bg-white border-stone-200 text-stone-700 hover:bg-orange-50/40'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        {isChecked ? (
                          <CheckSquare className="w-4 h-4 text-emerald-600 shrink-0" />
                        ) : (
                          <Square className="w-4 h-4 text-stone-400 shrink-0" />
                        )}
                        <span className={isChecked ? 'line-through text-stone-400' : 'font-medium'}>
                          {item.item}
                        </span>
                      </div>
                      <span className="text-xs font-semibold px-2 py-0.5 rounded bg-orange-100/70 text-orange-800">
                        {item.qty}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Right Column: Booking Section & Pricing Summary */}
          <div
            className={`md:col-span-5 ${
              activeTab === 'booking' ? 'block' : 'hidden md:block'
            }`}
          >
            {confirmedBookingId ? (
              /* Booking Success Confirmation State */
              <div className="bg-emerald-50 border border-emerald-300 rounded-2xl p-6 text-center space-y-4 animate-in zoom-in-95 duration-200">
                <div className="w-14 h-14 bg-emerald-600 text-white rounded-full flex items-center justify-center mx-auto shadow-lg">
                  <CheckCircle2 className="w-8 h-8" />
                </div>
                <div>
                  <span className="text-xs font-bold uppercase tracking-wider text-emerald-800">
                    Booking Confirmed • ଜୟ ଜଗନ୍ନାଥ
                  </span>
                  <h3 className="text-xl font-bold text-stone-900 mt-1">
                    Puja Pandit Assigned!
                  </h3>
                  <p className="text-xs text-stone-600 mt-1">
                    A certified Vedic Purohit from <strong>{district}</strong> is reserved for your puja.
                  </p>
                </div>

                <div className="bg-white rounded-xl p-3 border border-emerald-200 text-xs text-left space-y-1.5">
                  <div className="flex justify-between">
                    <span className="text-stone-500">Booking ID:</span>
                    <span className="font-mono font-bold text-emerald-800">
                      {confirmedBookingId.slice(0, 13)}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-stone-500">Date & Muhurat:</span>
                    <span className="font-semibold text-stone-800">
                      {bookingDate} ({bookingTime})
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-stone-500">Devotee Name:</span>
                    <span className="font-semibold text-stone-800">{userName || profile?.full_name}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-stone-500">Total Dakshina:</span>
                    <span className="font-bold text-orange-600">
                      ₹{totalDakshina.toLocaleString('en-IN')}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-stone-500">Samagri Kit:</span>
                    <span className="font-semibold text-stone-800">
                      {includeSamagri ? 'Included (Pandit brings)' : 'Arranged by Devotee'}
                    </span>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={onClose}
                  className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-lg text-sm transition shadow-md"
                >
                  Done (ଧନ୍ୟବାଦ)
                </button>
              </div>
            ) : (
              /* Interactive Booking Form */
              <div className="bg-stone-50 rounded-2xl p-5 border border-stone-200 shadow-xs space-y-4">
                <div className="flex items-center justify-between border-b border-stone-200 pb-3">
                  <div>
                    <h3 className="font-bold text-stone-900 text-base">
                      Book Puja Pandit
                    </h3>
                    <p className="text-xs text-stone-500">Verified Purohit Booking</p>
                  </div>
                  <div className="text-right">
                    <div className="text-xs text-stone-400">Total Dakshina</div>
                    <div className="text-xl font-black text-orange-700">
                      ₹{totalDakshina.toLocaleString('en-IN')}
                    </div>
                  </div>
                </div>

                {bookingError && (
                  <div className="p-2.5 bg-red-50 border border-red-200 rounded-lg text-xs text-red-700 flex items-start gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0 text-red-600 mt-0.5" />
                    <span>{bookingError}</span>
                  </div>
                )}

                <form onSubmit={handleBookingSubmit} className="space-y-3.5">
                  {/* Date & Muhurat */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    <div>
                      <label className="block text-xs font-semibold text-stone-700 mb-1">
                        Puja Date
                      </label>
                      <div className="relative">
                        <Calendar className="w-3.5 h-3.5 text-stone-400 absolute left-2.5 top-2.5" />
                        <input
                          type="date"
                          required
                          value={bookingDate}
                          onChange={(e) => setBookingDate(e.target.value)}
                          className="w-full pl-8 pr-2 py-1.5 text-xs border border-stone-300 rounded-lg focus:ring-1 focus:ring-orange-500 bg-white"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-stone-700 mb-1">
                        Muhurat Time
                      </label>
                      <select
                        value={bookingTime}
                        onChange={(e) => setBookingTime(e.target.value)}
                        className="w-full px-2 py-1.5 text-xs border border-stone-300 rounded-lg focus:ring-1 focus:ring-orange-500 bg-white"
                      >
                        {MUHURAT_SLOTS.map((slot) => (
                          <option key={slot.time} value={slot.time}>
                            {slot.time} - {slot.label.split('(')[0]}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  {/* District */}
                  <div>
                    <label className="block text-xs font-semibold text-stone-700 mb-1">
                      Odisha District (ଜିଲ୍ଲା)
                    </label>
                    <div className="relative">
                      <MapPin className="w-3.5 h-3.5 text-orange-600 absolute left-2.5 top-2.5" />
                      <select
                        value={district}
                        onChange={(e) => setDistrict(e.target.value as OdishaDistrict)}
                        className="w-full pl-8 pr-2 py-1.5 text-xs border border-stone-300 rounded-lg focus:ring-1 focus:ring-orange-500 bg-white"
                      >
                        {ODISHA_DISTRICTS.map((dist) => (
                          <option key={dist} value={dist}>
                            {dist}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  {/* Devotee Name & Phone */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    <div>
                      <label className="block text-xs font-semibold text-stone-700 mb-1">
                        Devotee Name
                      </label>
                      <div className="relative">
                        <User className="w-3.5 h-3.5 text-stone-400 absolute left-2.5 top-2.5" />
                        <input
                          type="text"
                          required
                          value={userName}
                          onChange={(e) => setUserName(e.target.value)}
                          placeholder="Your name"
                          className="w-full pl-8 pr-2 py-1.5 text-xs border border-stone-300 rounded-lg focus:ring-1 focus:ring-orange-500 bg-white"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-stone-700 mb-1">
                        Contact Phone
                      </label>
                      <div className="relative">
                        <Phone className="w-3.5 h-3.5 text-stone-400 absolute left-2.5 top-2.5" />
                        <input
                          type="tel"
                          required
                          value={userPhone}
                          onChange={(e) => setUserPhone(e.target.value)}
                          placeholder="Phone number"
                          className="w-full pl-8 pr-2 py-1.5 text-xs border border-stone-300 rounded-lg focus:ring-1 focus:ring-orange-500 bg-white"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Puja Location Address */}
                  <div>
                    <label className="block text-xs font-semibold text-stone-700 mb-1">
                      Puja Address / Location (ଘର ଠିକଣା)
                    </label>
                    <textarea
                      required
                      rows={2}
                      value={address}
                      onChange={(e) => setAddress(e.target.value)}
                      placeholder="House No, Landmark, Village / Colony, City"
                      className="w-full p-2 text-xs border border-stone-300 rounded-lg focus:ring-1 focus:ring-orange-500 bg-white resize-none"
                    />
                  </div>

                  {/* Samagri Kit Toggle */}
                  <div
                    onClick={() => setIncludeSamagri(!includeSamagri)}
                    className={`p-3 rounded-xl border cursor-pointer transition select-none flex items-start gap-3 ${
                      includeSamagri
                        ? 'bg-amber-50 border-amber-400 ring-1 ring-amber-400'
                        : 'bg-white border-stone-200 hover:border-orange-300'
                    }`}
                  >
                    <div className="pt-0.5">
                      <input
                        type="checkbox"
                        checked={includeSamagri}
                        onChange={() => {}}
                        className="w-4 h-4 text-orange-600 rounded-sm focus:ring-orange-500 accent-orange-600"
                      />
                    </div>
                    <div className="flex-1 text-xs">
                      <div className="flex items-center justify-between font-semibold text-stone-900">
                        <span className="flex items-center gap-1">
                          <PackageCheck className="w-3.5 h-3.5 text-amber-600" />
                          Bring Complete Samagri Kit
                        </span>
                        <span className="text-orange-700 font-bold">+₹750</span>
                      </div>
                      <p className="text-[11px] text-stone-500 mt-0.5">
                        Pandit Ji will bring all Ghee, Kalash, Nirmalya, Havan wood, and sacred herbs. Hassle-free experience!
                      </p>
                    </div>
                  </div>

                  {/* Dakshina Breakdown */}
                  <div className="bg-white p-2.5 rounded-lg border border-stone-200 text-xs space-y-1">
                    <div className="flex justify-between text-stone-600">
                      <span>Base Vedic Dakshina:</span>
                      <span>₹{baseDakshina.toLocaleString('en-IN')}</span>
                    </div>
                    {includeSamagri && (
                      <div className="flex justify-between text-amber-700 font-medium">
                        <span>Complete Samagri Kit:</span>
                        <span>+₹750</span>
                      </div>
                    )}
                    <div className="border-t border-dashed border-stone-200 pt-1 flex justify-between font-bold text-stone-900">
                      <span>Total Dakshina:</span>
                      <span className="text-orange-700 text-sm">
                        ₹{totalDakshina.toLocaleString('en-IN')}
                      </span>
                    </div>
                  </div>

                  {/* Submit / Book Button */}
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full py-3 bg-gradient-to-r from-orange-600 via-amber-600 to-red-600 hover:from-orange-700 hover:to-red-700 text-white font-bold rounded-xl text-sm shadow-md hover:shadow-lg transition flex items-center justify-center gap-2 disabled:opacity-50"
                  >
                    {isSubmitting ? (
                      'Securing Pandit...'
                    ) : (
                      <>
                        <span>Book Pandit (ପୁରୋହିତ ବୁକିଂ)</span>
                        <ArrowRight className="w-4 h-4" />
                      </>
                    )}
                  </button>

                  {!user && !profile && (
                    <p className="text-[11px] text-center text-stone-500">
                      🔒 You will be asked to sign in or use demo login upon clicking book.
                    </p>
                  )}
                </form>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
