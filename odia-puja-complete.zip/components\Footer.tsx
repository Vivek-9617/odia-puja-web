'use client';

import React from 'react';
import Link from 'next/link';
import { Phone, Mail, MapPin, Heart, ShieldCheck } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-stone-900 text-stone-300 border-t-4 border-orange-600">
      {/* Top Auspicious Sloka */}
      <div className="bg-stone-950 py-3 text-center border-b border-stone-800 text-xs text-amber-200/90 font-serif tracking-wider px-4">
        ॐ ସର୍ବେ ଭବନ୍ତୁ ସୁଖିନଃ ସର୍ବେ ସନ୍ତୁ ନିରାମୟାଃ • ସର୍ବେ ଭଦ୍ରାଣି ପଶ୍ୟନ୍ତୁ ମା କଶ୍ଚିଦ୍ ଦୁଃଖଭାଗ୍ ଭବେତ୍ ॐ
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Col 1: About Platform */}
          <div className="space-y-3 md:col-span-1">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-orange-600 text-white flex items-center justify-center font-serif text-lg font-bold">
                🪔
              </div>
              <span className="text-xl font-black font-serif text-white tracking-tight">
                Odia<span className="text-orange-500">Puja</span>
              </span>
            </div>
            <p className="text-xs text-stone-400 leading-relaxed">
              Odisha&apos;s trusted digital platform connecting devotees with certified Vedic Purohits across all 30 districts for Satyanarayana Vrata, Griha Pravesh, Rudrabhishek, and authentic Utkaliya rituals.
            </p>
            <div className="flex items-center gap-1.5 text-xs text-emerald-400 font-semibold">
              <ShieldCheck className="w-4 h-4" />
              <span>Mukti Mandap &amp; Vedic Council Aligned</span>
            </div>
          </div>

          {/* Col 2: Auspicious Pujas */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold text-white uppercase tracking-wider font-serif border-b border-stone-800 pb-1">
              Popular Pujas (ପ୍ରସିଦ୍ଧ ପୂଜା)
            </h4>
            <ul className="space-y-1.5 text-xs text-stone-400">
              <li>
                <Link href="/" className="hover:text-orange-400 transition">
                  Satyanarayana Puja (ସତ୍ୟନାରାୟଣ ପୂଜା)
                </Link>
              </li>
              <li>
                <Link href="/" className="hover:text-orange-400 transition">
                  Griha Pravesh &amp; Vastu (ଗୃହ ପ୍ରବେଶ)
                </Link>
              </li>
              <li>
                <Link href="/" className="hover:text-orange-400 transition">
                  Manabasa Gurubar (ମାଣବସା ଗୁରୁବାର)
                </Link>
              </li>
              <li>
                <Link href="/" className="hover:text-orange-400 transition">
                  Maha Rudrabhishek (ମହା ରୁଦ୍ରାଭିଷେକ)
                </Link>
              </li>
              <li>
                <Link href="/" className="hover:text-orange-400 transition">
                  Jagannath Puja &amp; Havan (ଜଗନ୍ନାଥ ପୂଜା)
                </Link>
              </li>
              <li>
                <Link href="/" className="hover:text-orange-400 transition">
                  Sudasha Brata (ସୁଦଶା ବ୍ରତ)
                </Link>
              </li>
            </ul>
          </div>

          {/* Col 3: Quick Navigation */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold text-white uppercase tracking-wider font-serif border-b border-stone-800 pb-1">
              Platform Services
            </h4>
            <ul className="space-y-1.5 text-xs text-stone-400">
              <li>
                <Link href="/pandits" className="hover:text-orange-400 transition">
                  Verified Pandits Directory
                </Link>
              </li>
              <li>
                <Link href="/pandit-register" className="hover:text-orange-400 transition">
                  Register as Pandit Ji (ପୁରୋହିତ ପଞ୍ଜୀକରଣ)
                </Link>
              </li>
              <li>
                <Link href="/admin" className="hover:text-orange-400 transition">
                  Admin Verification Portal
                </Link>
              </li>
              <li>
                <span className="text-stone-500">
                  Complete Samagri Kit Delivery (ପୂଜା କିଟ୍)
                </span>
              </li>
              <li>
                <span className="text-stone-500">
                  Auspicious Muhurat Consultation
                </span>
              </li>
            </ul>
          </div>

          {/* Col 4: Odisha Districts & Helpline */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold text-white uppercase tracking-wider font-serif border-b border-stone-800 pb-1">
              Devotee Helpline
            </h4>
            <div className="space-y-2 text-xs text-stone-400">
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-orange-500 shrink-0" />
                <span className="font-semibold text-white">+91 98610 12345 / 94371 28910</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-orange-500 shrink-0" />
                <span>support@odiapuja.in</span>
              </div>
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-orange-500 shrink-0 mt-0.5" />
                <span>Bhubaneswar &amp; Puri, Odisha - 751001</span>
              </div>
            </div>
            <p className="text-[11px] text-stone-500 pt-1">
              Active in Bhubaneswar, Cuttack, Puri, Berhampur, Sambalpur, Balasore, Rourkela &amp; all 30 districts.
            </p>
          </div>
        </div>

        <div className="mt-8 pt-6 border-t border-stone-800 flex flex-col sm:flex-row items-center justify-between text-xs text-stone-500 gap-3">
          <p>© 2026 OdiaPuja. Odisha Pandit &amp; Puja Booking Platform. All rights reserved.</p>
          <p className="flex items-center gap-1">
            Built with <Heart className="w-3.5 h-3.5 text-red-500 fill-red-500" /> for devotees of Mahaprabhu Jagannath.
          </p>
        </div>
      </div>
    </footer>
  );
}
