'use client';

import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/supabase';
import { X, Lock, Mail, User, Phone, Sparkles, CheckCircle2, AlertCircle } from 'lucide-react';

export default function AuthModal() {
  const router = useRouter();
  const {
    isAuthModalOpen,
    authModalTab,
    openAuthModal,
    closeAuthModal,
    setDemoUser,
  } = useAuth();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [role, setRole] = useState<'user' | 'pandit'>('user');
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  if (!isAuthModalOpen) return null;

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setErrorMsg('');
    setSuccessMsg('');

    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email: email.trim(),
        password: password,
      });

      if (error) {
        throw error;
      }

      if (data.user) {
        setSuccessMsg('Jai Jagannath! Login successful.');
        setTimeout(() => {
          closeAuthModal();
        }, 800);
      }
    } catch (err: unknown) {
      setErrorMsg((err as Error).message || 'Login failed. Please check your credentials.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setErrorMsg('');
    setSuccessMsg('');

    if (!fullName.trim() || !phone.trim()) {
      setErrorMsg('Please enter your full name and phone number.');
      setIsLoading(false);
      return;
    }

    try {
      const { error } = await supabase.auth.signUp({
        email: email.trim(),
        password: password,
        options: {
          data: {
            full_name: fullName.trim(),
            phone: phone.trim(),
            role: role,
          },
        },
      });

      if (error) {
        throw error;
      }

      setSuccessMsg('Account created successfully!');
      setTimeout(() => {
        closeAuthModal();
        if (role === 'pandit') {
          router.push('/pandit-register');
        }
      }, 1000);
    } catch (err: unknown) {
      setErrorMsg((err as Error).message || 'Signup failed. Please try again or use instant demo.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-md bg-white rounded-2xl shadow-2xl border border-orange-200 overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header Banner */}
        <div className="bg-gradient-to-r from-orange-600 via-amber-600 to-red-700 text-white p-6 relative">
          <button
            onClick={closeAuthModal}
            className="absolute top-4 right-4 text-white/80 hover:text-white bg-black/20 hover:bg-black/40 rounded-full p-1.5 transition"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-2 mb-1">
            <span className="text-xl">🪔</span>
            <span className="text-xs uppercase tracking-widest font-semibold text-orange-200">
              ଜୟ ଜଗନ୍ନାଥ • OdiaPuja
            </span>
          </div>
          <h2 className="text-2xl font-bold font-serif">
            {authModalTab === 'login' ? 'Welcome Back, Devotee' : 'Join OdiaPuja Platform'}
          </h2>
          <p className="text-xs text-orange-100 mt-1">
            {authModalTab === 'login'
              ? 'Sign in to book auspicious pujas, track muhurat, or manage pandit bookings.'
              : 'Register to book authentic Vedic pujas or register as a verified Purohit.'}
          </p>
        </div>

        {/* Tab switch */}
        <div className="flex border-b border-orange-100 bg-orange-50/50">
          <button
            type="button"
            onClick={() => {
              openAuthModal('login');
              setErrorMsg('');
              setSuccessMsg('');
            }}
            className={`flex-1 py-3 text-sm font-semibold transition ${
              authModalTab === 'login'
                ? 'text-orange-700 border-b-2 border-orange-600 bg-white'
                : 'text-stone-500 hover:text-stone-800'
            }`}
          >
            Sign In (ପ୍ରବେଶ)
          </button>
          <button
            type="button"
            onClick={() => {
              openAuthModal('signup');
              setErrorMsg('');
              setSuccessMsg('');
            }}
            className={`flex-1 py-3 text-sm font-semibold transition ${
              authModalTab === 'signup'
                ? 'text-orange-700 border-b-2 border-orange-600 bg-white'
                : 'text-stone-500 hover:text-stone-800'
            }`}
          >
            Sign Up (ପଞ୍ଜୀକରଣ)
          </button>
        </div>

        <div className="p-6">
          {errorMsg && (
            <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg text-xs text-red-700 flex items-start gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-red-600 mt-0.5" />
              <span>{errorMsg}</span>
            </div>
          )}

          {successMsg && (
            <div className="mb-4 p-3 bg-emerald-50 border border-emerald-200 rounded-lg text-xs text-emerald-700 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
              <span>{successMsg}</span>
            </div>
          )}

          {authModalTab === 'login' ? (
            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  Email Address
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-stone-400 absolute left-3 top-3" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="devotee@gmail.com"
                    className="w-full pl-9 pr-3 py-2 text-sm border border-stone-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  Password
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-stone-400 absolute left-3 top-3" />
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-9 pr-3 py-2 text-sm border border-stone-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-2.5 bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-700 hover:to-red-700 text-white font-semibold rounded-lg text-sm shadow-md transition disabled:opacity-50"
              >
                {isLoading ? 'Signing in...' : 'Sign In with Supabase'}
              </button>
            </form>
          ) : (
            <form onSubmit={handleSignUp} className="space-y-3.5">
              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  Full Name (ପୂର୍ଣ୍ଣ ନାମ)
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-stone-400 absolute left-3 top-3" />
                  <input
                    type="text"
                    required
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="e.g. Bhabani Shankar Dash"
                    className="w-full pl-9 pr-3 py-2 text-sm border border-stone-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  Phone Number (ମୋବାଇଲ ନମ୍ବର)
                </label>
                <div className="relative">
                  <Phone className="w-4 h-4 text-stone-400 absolute left-3 top-3" />
                  <input
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="e.g. 9861012345"
                    className="w-full pl-9 pr-3 py-2 text-sm border border-stone-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  Email Address
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-stone-400 absolute left-3 top-3" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="you@gmail.com"
                    className="w-full pl-9 pr-3 py-2 text-sm border border-stone-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  Password
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-stone-400 absolute left-3 top-3" />
                  <input
                    type="password"
                    required
                    minLength={6}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="At least 6 characters"
                    className="w-full pl-9 pr-3 py-2 text-sm border border-stone-300 rounded-lg focus:outline-hidden focus:ring-2 focus:ring-orange-500 focus:border-orange-500"
                  />
                </div>
              </div>

              {/* Role Selector */}
              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1.5">
                  I want to join as:
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setRole('user')}
                    className={`p-2.5 rounded-lg border text-xs font-medium flex flex-col items-center gap-1 transition ${
                      role === 'user'
                        ? 'border-orange-600 bg-orange-50 text-orange-800 font-semibold ring-1 ring-orange-500'
                        : 'border-stone-200 text-stone-600 hover:bg-stone-50'
                    }`}
                  >
                    <span>🙏 Devotee (ଭକ୍ତ)</span>
                    <span className="text-[10px] text-stone-400">Book Pujas</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setRole('pandit')}
                    className={`p-2.5 rounded-lg border text-xs font-medium flex flex-col items-center gap-1 transition ${
                      role === 'pandit'
                        ? 'border-orange-600 bg-orange-50 text-orange-800 font-semibold ring-1 ring-orange-500'
                        : 'border-stone-200 text-stone-600 hover:bg-stone-50'
                    }`}
                  >
                    <span>🪔 Pandit Ji (ପୁରୋହିତ)</span>
                    <span className="text-[10px] text-stone-400">Offer Services</span>
                  </button>
                </div>
                {role === 'pandit' && (
                  <p className="text-[11px] text-amber-700 mt-1.5 bg-amber-50 p-2 rounded border border-amber-200">
                    ℹ️ You will be redirected to complete your Vedic qualification and district details after sign up.
                  </p>
                )}
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-2.5 bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-700 hover:to-red-700 text-white font-semibold rounded-lg text-sm shadow-md transition disabled:opacity-50"
              >
                {isLoading ? 'Creating Account...' : 'Complete Sign Up'}
              </button>
            </form>
          )}

          {/* Quick Demo Access Bar */}
          <div className="mt-5 pt-4 border-t border-stone-200">
            <div className="flex items-center gap-1.5 text-xs font-semibold text-stone-600 mb-2">
              <Sparkles className="w-3.5 h-3.5 text-orange-600" />
              <span>Instant Demo Access (No password needed):</span>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setDemoUser('user')}
                className="py-1.5 px-2 bg-orange-100 hover:bg-orange-200 text-orange-800 text-xs rounded-md font-medium text-center transition"
              >
                Login as Devotee
              </button>
              <button
                type="button"
                onClick={() => setDemoUser('pandit')}
                className="py-1.5 px-2 bg-amber-100 hover:bg-amber-200 text-amber-800 text-xs rounded-md font-medium text-center transition"
              >
                Login as Pandit Ji
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
