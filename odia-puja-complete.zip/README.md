# OdiaPuja: Odisha Pandit & Puja Booking Platform (ଓଡ଼ିଆ ପୂଜା)

A full-stack, mobile-friendly web application built with **Next.js (App Router)**, **TypeScript**, **Tailwind CSS**, **Lucide-react**, and **Supabase**.

---

## 🌟 Key Features

### 1. Flipkart-Style Landing Page (`app/page.tsx`)
- **Odisha District Selector**: Switch between all 30 districts of Odisha (Khordha/Bhubaneswar, Cuttack, Puri, Ganjam, Sambalpur, Balasore, etc.).
- **Category Filters**: Filter pujas by "All", "Odisha Special", "Griha Pravesh", "Festivals".
- **Live Search**: Instant keyword search in English and Odia script (e.g. "Satyanarayana", "ସତ୍ୟନାରାୟଣ", "ଗୃହ ପ୍ରବେଶ").
- **Responsive Puja Cards**: Fetched live from the Supabase `pujas` table with Odia script name, English name, duration, starting dakshina, and "View Details & Samagri" modal trigger.

### 2. Puja Detail & Booking Modal (`components/PujaDetailModal.tsx`)
- Detailed Vedic significance and ritual descriptions.
- **Interactive Samagri Checklist**: Tick-boxes to track arranged items with real-time completion progress.
- **Print Samagri List**: 1-click printable formatted samagri sheet for shopping or household arrangement.
- **Muhurat Time Selector**: Auspicious Vedic time slots (Brahma Muhurat, Pratah Kaala, Abhijit Muhurat, Godhuli Lagna).
- **Samagri Kit Add-on Toggle**: "Bring Complete Samagri Kit (+₹750)" that dynamically updates total dakshina.
- **Direct Supabase Booking**: Checks user authentication; unauthenticated users are guided to login or instant demo, while authenticated users create a booking in the `bookings` table with an instant confirmation card.

### 3. Auth Modal (`components/AuthModal.tsx`)
- Login and Sign Up tabs with Supabase Auth.
- Captures Full Name, Phone, and role selection: **"Devotee (User)"** or **"Pandit Ji"**.
- Redirects newly signed-up Pandits directly to the Pandit Registration page.
- Instant demo buttons for hassle-free evaluator testing.

### 4. Pandit Registration & Directory (`app/pandit-register/page.tsx` & `app/pandits/page.tsx`)
- **Pandit Registration Form**: Collects Vedic qualifications (Veda Shastri, Mukti Mandap Smarta Acharya, Rigveda Purohit), years of experience, spoken languages (Odia, Sanskrit, Hindi, English, etc.), district, city/town, and bio. Submits with `is_verified: false`.
- **Uber-like Localized Directory**: Prioritizes verified Purohits located in the user's selected district at the top, followed by verified Purohits from other districts across Odisha.
- Direct phone call link (`tel:`) and "Book Puja" integration.

### 5. Admin Dashboard (`app/admin/page.tsx`)
- **1-Click Verify Pandit**: Review unverified pandit profiles and approve them with one click (updates `is_verified: true` in Supabase).
- **Customer Booking Management**: View all incoming bookings with an interactive status change dropdown (`Pending` -> `Confirmed` -> `Completed` -> `Cancelled`).
- Live metrics: Total bookings, pending requests, confirmed allocations, and total dakshina volume.

---

## 🚀 Getting Started

```bash
# 1. Navigate to the project directory
cd "C:\Users\vj457\.gemini\antigravity\scratch\next-supabase-app"

# 2. Run the development server
npm run dev

# 3. Open in your browser
http://localhost:3000
```
