'use client';

import React, { useState, useEffect, useMemo } from 'react';
import { supabase } from '@/lib/supabase';
import { Puja, PUJA_CATEGORIES } from '@/types/database';
import { FALLBACK_PUJAS } from '@/lib/data';
import { useAuth } from '@/context/AuthContext';
import PujaDetailModal from '@/components/PujaDetailModal';
import {
  Clock,
  Sparkles,
  Search,
  ShieldCheck,
  CheckCircle2,
  Calendar,
  Flame,
  ArrowRight
} from 'lucide-react';
import Link from 'next/link';

export default function HomePage() {
  const { selectedDistrict } = useAuth();
  const [pujas, setPujas] = useState<Puja[]>(FALLBACK_PUJAS);
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedPujaForModal, setSelectedPujaForModal] = useState<Puja | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Fetch pujas directly from Supabase 'pujas' table
  useEffect(() => {
    async function loadPujas() {
      const { data, error } = await supabase.from('pujas').select('*');
      if (data && !error && data.length > 0) {
        setPujas(data);
      }
    }

    loadPujas();
  }, []);

  // Filter based on category and search query
  const filteredPujas = useMemo(() => {
    let result = pujas;

    if (selectedCategory !== 'All') {
      result = result.filter(
        (p) => p.category?.toLowerCase() === selectedCategory.toLowerCase()
      );
    }

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      result = result.filter(
        (p) =>
          p.name_english?.toLowerCase().includes(q) ||
          p.name_odia?.includes(q) ||
          p.description?.toLowerCase().includes(q)
      );
    }

    return result;
  }, [pujas, selectedCategory, searchQuery]);

  const handleOpenPuja = (puja: Puja) => {
    setSelectedPujaForModal(puja);
    setIsModalOpen(true);
  };

  return (
    <div className="min-h-screen bg-stone-50 pb-20">
      {/* Flipkart-Style Hero Banner Section */}
      <section className="bg-gradient-to-b from-orange-600 via-amber-600 to-amber-700 text-white pt-8 pb-14 px-4 sm:px-6 relative overflow-hidden">
        {/* Decorative backdrop elements */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-yellow-400/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-80 h-80 bg-red-800/20 rounded-full blur-2xl pointer-events-none" />

        <div className="max-w-7xl mx-auto relative z-10">
          <div className="text-center max-w-3xl mx-auto space-y-3">
            <div className="inline-flex items-center gap-2 bg-amber-500/30 backdrop-blur-md border border-amber-300/40 rounded-full px-3.5 py-1 text-xs font-semibold text-amber-100 shadow-xs">
              <Sparkles className="w-3.5 h-3.5 text-yellow-300" />
              <span>Odisha&apos;s Trusted Vedic Pandit &amp; Ritual Network</span>
            </div>

            <h1 className="text-3xl sm:text-5xl font-extrabold font-serif tracking-tight text-white leading-tight">
              ବୈଦିକ ପୁରୋହିତ ଓ ଶୁଦ୍ଧ ପୂଜା ସେବା
            </h1>
            <p className="text-sm sm:text-lg text-amber-100 max-w-2xl mx-auto font-medium">
              Book certified Purohits for authentic Utkaliya pujas, Griha Pravesh, Havan, and festivals in <strong suppressHydrationWarning={true}>{selectedDistrict}</strong>.
            </p>

            {/* Quick Search Bar */}
            <div className="pt-3 max-w-xl mx-auto">
              <div className="relative">
                <Search className="w-5 h-5 text-stone-400 absolute left-4 top-3.5" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search puja in English or Odia (e.g. Satyanarayana, ଗୃହ ପ୍ରବେଶ)..."
                  className="w-full pl-12 pr-4 py-3 bg-white text-stone-900 rounded-2xl shadow-xl text-sm placeholder-stone-400 focus:outline-hidden focus:ring-4 focus:ring-amber-300"
                />
              </div>
            </div>

            {/* Flipkart-Style Feature Badges */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-4 max-w-4xl mx-auto text-xs text-amber-100">
              <div className="flex items-center justify-center gap-1.5 bg-black/15 backdrop-blur-xs py-2 px-3 rounded-xl border border-white/10">
                <ShieldCheck className="w-4 h-4 text-amber-300 shrink-0" />
                <span>100% Verified Pandits</span>
              </div>
              <div className="flex items-center justify-center gap-1.5 bg-black/15 backdrop-blur-xs py-2 px-3 rounded-xl border border-white/10">
                <Flame className="w-4 h-4 text-yellow-300 shrink-0" />
                <span>Samagri Kit Available</span>
              </div>
              <div className="flex items-center justify-center gap-1.5 bg-black/15 backdrop-blur-xs py-2 px-3 rounded-xl border border-white/10">
                <Calendar className="w-4 h-4 text-amber-300 shrink-0" />
                <span>Accurate Muhurat Match</span>
              </div>
              <div className="flex items-center justify-center gap-1.5 bg-black/15 backdrop-blur-xs py-2 px-3 rounded-xl border border-white/10">
                <CheckCircle2 className="w-4 h-4 text-emerald-300 shrink-0" />
                <span>Fixed Dakshina Guarantee</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Main Container */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-6">
        {/* Flipkart-Style Category Pills Bar */}
        <div className="bg-white rounded-2xl p-3 shadow-md border border-stone-200 flex items-center justify-between gap-2 overflow-x-auto scrollbar-none mb-8">
          <div className="flex items-center gap-2">
            {PUJA_CATEGORIES.map((category) => {
              const isSelected = selectedCategory === category;
              return (
                <button
                  key={category}
                  onClick={() => setSelectedCategory(category)}
                  className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap transition flex items-center gap-1.5 ${
                    isSelected
                      ? 'bg-gradient-to-r from-orange-600 to-red-600 text-white shadow-sm'
                      : 'bg-stone-100 hover:bg-stone-200 text-stone-700'
                  }`}
                >
                  {category === 'All' && <span>🪔</span>}
                  {category === 'Odisha Special' && <span>🚩</span>}
                  {category === 'Griha Pravesh' && <span>🏠</span>}
                  {category === 'Festivals' && <span>🌸</span>}
                  <span>{category}</span>
                </button>
              );
            })}
          </div>

          <div className="hidden md:flex items-center gap-3 text-xs font-semibold text-stone-500 pr-2">
            <span>Serving: <strong className="text-orange-700" suppressHydrationWarning={true}>{selectedDistrict}</strong></span>
            <span>•</span>
            <Link
              href="/pandits"
              className="text-orange-600 hover:text-orange-700 hover:underline flex items-center gap-1"
            >
              Browse Pandits <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>
        </div>

        {/* Section Heading */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-6">
          <div>
            <h2 className="text-xl sm:text-2xl font-bold font-serif text-stone-900 flex items-center gap-2">
              <span suppressHydrationWarning={true}>Auspicious Pujas for {selectedDistrict}</span>
              <span className="text-xs bg-orange-100 text-orange-800 font-semibold px-2 py-0.5 rounded-full">
                {filteredPujas.length} Available
              </span>
            </h2>
            <p className="text-xs text-stone-500 mt-0.5">
              Select a puja to view ritual procedure, complete samagri checklist, and book certified Purohits.
            </p>
          </div>
        </div>

        {/* Responsive Grid of Puja Cards */}
        {filteredPujas.length === 0 ? (
          <div className="bg-white rounded-2xl p-12 text-center border border-stone-200 max-w-md mx-auto space-y-3">
            <span className="text-4xl">🔍</span>
            <h3 className="font-bold text-stone-800 text-lg">No Pujas Found</h3>
            <p className="text-xs text-stone-500">
              No pujas match &ldquo;{searchQuery}&rdquo;. Try another category or search keyword.
            </p>
            <button
              onClick={() => {
                setSelectedCategory('All');
                setSearchQuery('');
              }}
              className="px-4 py-2 bg-orange-600 text-white rounded-xl text-xs font-semibold hover:bg-orange-700 transition"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredPujas.map((puja) => (
              <div
                key={puja.id}
                className="bg-white rounded-2xl border border-stone-200 hover:border-orange-300 shadow-xs hover:shadow-xl transition-all duration-300 overflow-hidden flex flex-col group"
              >
                {/* Puja Card Image Banner */}
                <div className="relative h-48 w-full bg-stone-100 overflow-hidden">
                  <img
                    src={puja.image_url}
                    alt={puja.name_english}
                    referrerPolicy="no-referrer"
                    onError={(e) => {
                      e.currentTarget.src =
                        "https://images.unsplash.com/photo-1605371924599-2d0365da1ae0?auto=format&fit=crop&w=800&q=80";
                    }}
                    className="w-full h-full object-cover group-hover:scale-105 transition duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />

                  {/* Category Pill */}
                  <div className="absolute top-3 left-3">
                    <span className="px-2.5 py-1 rounded-full text-[11px] font-bold bg-white/90 text-stone-800 backdrop-blur-md shadow-xs">
                      {puja.category}
                    </span>
                  </div>

                  {/* Duration Pill */}
                  <div className="absolute top-3 right-3">
                    <span className="flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-semibold bg-black/60 text-white backdrop-blur-md">
                      <Clock className="w-3 h-3 text-amber-300" />
                      {puja.duration_hours}h
                    </span>
                  </div>

                  {/* Odia & English Name on Image */}
                  <div className="absolute bottom-3 left-3 right-3 text-white">
                    <div className="text-amber-300 font-bold font-serif text-sm tracking-wide">
                      {puja.name_odia}
                    </div>
                    <h3 className="font-bold font-serif text-lg leading-snug truncate">
                      {puja.name_english}
                    </h3>
                  </div>
                </div>

                {/* Card Body */}
                <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
                  <p className="text-xs text-stone-600 line-clamp-2 leading-relaxed">
                    {puja.description}
                  </p>

                  {/* Samagri Preview */}
                  <div className="bg-orange-50/70 rounded-xl p-2.5 border border-orange-100 text-xs">
                    <div className="flex items-center justify-between text-[11px] font-bold text-orange-950 mb-1">
                      <span>Key Samagri Items:</span>
                      <span className="text-orange-700 font-medium">
                        {puja.samagri_list?.length || 4}+ Items
                      </span>
                    </div>
                    <div className="text-[11px] text-stone-600 truncate">
                      {(puja.samagri_list || [])
                        .slice(0, 3)
                        .map((s) => s.item)
                        .join(' • ')}
                    </div>
                  </div>

                  {/* Pricing & CTA */}
                  <div className="pt-2 border-t border-stone-100 flex items-center justify-between">
                    <div>
                      <div className="text-[11px] text-stone-400 font-medium">Starting Dakshina</div>
                      <div className="text-xl font-black text-orange-700 font-serif">
                        ₹{(puja.base_dakshina || 1501).toLocaleString('en-IN')}
                      </div>
                    </div>

                    <button
                      onClick={() => handleOpenPuja(puja)}
                      className="px-4 py-2.5 bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-700 hover:to-red-700 text-white rounded-xl text-xs font-bold shadow-md shadow-orange-600/20 hover:shadow-lg transition flex items-center gap-1.5"
                    >
                      <span>View &amp; Book</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Bottom Banner: Invite to Register as Pandit */}
        <div className="mt-14 bg-gradient-to-r from-stone-900 via-amber-950 to-stone-900 text-white rounded-3xl p-6 sm:p-10 border border-amber-600/30 shadow-2xl relative overflow-hidden">
          <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="space-y-2 text-center md:text-left">
              <span className="text-amber-400 font-bold text-xs uppercase tracking-widest flex items-center justify-center md:justify-start gap-1">
                <span>🪔</span> Vedic Purohit Onboarding
              </span>
              <h3 className="text-2xl sm:text-3xl font-bold font-serif text-amber-100">
                ଆପଣ ଜଣେ ବୈଦିକ ପୁରୋହିତ କି? Register as Pandit Ji
              </h3>
              <p className="text-stone-300 text-xs sm:text-sm max-w-xl">
                Join our statewide platform to connect with devotees across your district. Receive puja bookings directly with verified dakshina and scheduling support.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row items-center gap-3 shrink-0">
              <Link
                href="/pandit-register"
                className="px-6 py-3 bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 text-stone-950 font-black rounded-xl text-sm shadow-lg transition"
              >
                Register as Pandit Ji (ପଞ୍ଜୀକରଣ)
              </Link>
              <Link
                href="/pandits"
                className="px-5 py-3 bg-white/10 hover:bg-white/20 text-white font-bold rounded-xl text-sm border border-white/20 transition"
              >
                View Directory
              </Link>
            </div>
          </div>
        </div>
      </main>

      {/* Puja Detail & Booking Modal */}
      <PujaDetailModal
        puja={selectedPujaForModal}
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onBookingSuccess={() => {}}
      />
    </div>
  );
}
