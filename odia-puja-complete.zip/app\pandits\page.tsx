'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { supabase } from '@/lib/supabase';
import { PanditProfile, ODISHA_DISTRICTS, OdishaDistrict } from '@/types/database';
import { CURATED_PANDITS } from '@/lib/data';
import { useAuth } from '@/context/AuthContext';
import {
  MapPin,
  ShieldCheck,
  Star,
  Phone,
  Languages,
  Award,
  Search,
  ArrowRight,
} from 'lucide-react';

export default function PanditsDirectoryPage() {
  const { selectedDistrict, setSelectedDistrict } = useAuth();
  const [pandits, setPandits] = useState<PanditProfile[]>(CURATED_PANDITS);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeDistrictFilter, setActiveDistrictFilter] = useState<string>(selectedDistrict);

  // Sync with global district
  useEffect(() => {
    setActiveDistrictFilter(selectedDistrict);
  }, [selectedDistrict]);

  // Load verified pandits from Supabase
  useEffect(() => {
    async function loadPandits() {
      try {
        const { data, error } = await supabase
          .from('pandit_profiles')
          .select('*, profiles(full_name, phone)')
          .eq('is_verified', true);

        if (data && data.length > 0 && !error) {
          // Merge Supabase pandits with curated dataset (avoiding duplicates)
          const liveIds = new Set(data.map((p) => p.id));
          const supplementary = CURATED_PANDITS.filter((p) => !liveIds.has(p.id));
          setPandits([...data, ...supplementary]);
        } else {
          setPandits(CURATED_PANDITS);
        }
      } catch (err) {
        console.error('Error loading pandits from Supabase:', err);
        setPandits(CURATED_PANDITS);
      }
    }

    loadPandits();
  }, []);

  // Filter and split into local district vs other districts (Uber-like localized priority)
  const filteredList = pandits.filter((p) => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    const name = p.profiles?.full_name?.toLowerCase() || '';
    const qual = p.vedic_qualification?.toLowerCase() || '';
    const bio = p.bio?.toLowerCase() || '';
    const langs = (p.languages_spoken || []).join(' ').toLowerCase();
    const dist = p.district?.toLowerCase() || '';
    return (
      name.includes(q) ||
      qual.includes(q) ||
      bio.includes(q) ||
      langs.includes(q) ||
      dist.includes(q)
    );
  });

  // Split into:
  // 1. Pandits matching the user's active district
  // 2. Pandits from other districts
  const localPandits = filteredList.filter(
    (p) => p.district?.toLowerCase() === activeDistrictFilter.toLowerCase()
  );

  const otherPandits = filteredList.filter(
    (p) => p.district?.toLowerCase() !== activeDistrictFilter.toLowerCase()
  );

  return (
    <div className="min-h-screen bg-stone-50 pb-20">
      {/* Banner */}
      <section className="bg-gradient-to-r from-orange-700 via-amber-700 to-red-800 text-white py-10 px-4 sm:px-6">
        <div className="max-w-7xl mx-auto">
          <div className="max-w-3xl space-y-2">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/20 text-xs font-semibold text-amber-200 backdrop-blur-xs">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Mukti Mandap &amp; Utkal Sanskrit Parishad Verified</span>
            </div>
            <h1 className="text-3xl sm:text-4xl font-extrabold font-serif">
              Odisha Certified Pandit Directory
            </h1>
            <p className="text-xs sm:text-sm text-orange-100 leading-relaxed">
              Find and connect directly with certified Vedic Purohits across all 30 districts of Odisha. Local pandits are prioritized for your puja convenience.
            </p>
          </div>

          {/* Search & District Selector Filter Bar */}
          <div className="mt-6 bg-white text-stone-900 rounded-2xl p-3 shadow-xl grid grid-cols-1 sm:grid-cols-12 gap-3 items-center">
            {/* Search input */}
            <div className="sm:col-span-7 relative">
              <Search className="w-4 h-4 text-stone-400 absolute left-3 top-3" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search by Pandit name, qualification, or language..."
                className="w-full pl-9 pr-3 py-2 text-xs sm:text-sm border border-stone-200 rounded-xl focus:ring-2 focus:ring-orange-500"
              />
            </div>

            {/* District dropdown */}
            <div className="sm:col-span-5 relative">
              <MapPin className="w-4 h-4 text-orange-600 absolute left-3 top-3" />
              <select
                value={activeDistrictFilter}
                onChange={(e) => {
                  const d = e.target.value as OdishaDistrict;
                  setActiveDistrictFilter(d);
                  setSelectedDistrict(d);
                }}
                className="w-full pl-9 pr-3 py-2 text-xs sm:text-sm border border-stone-200 rounded-xl focus:ring-2 focus:ring-orange-500 bg-stone-50 font-semibold text-stone-800"
              >
                {ODISHA_DISTRICTS.map((district) => (
                  <option key={district} value={district}>
                    📍 {district}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 space-y-10">
        {/* Tier 1: Local District Pandits (Uber-Like Priority) */}
        <div>
          <div className="flex items-center justify-between mb-4 border-b border-orange-200 pb-2">
            <div>
              <h2 className="text-lg sm:text-xl font-bold font-serif text-stone-900 flex items-center gap-2">
                <span className="text-orange-600">📍</span>
                <span suppressHydrationWarning={true}>Verified Purohits in {activeDistrictFilter}</span>
                <span className="text-xs bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded-full">
                  {localPandits.length} Local
                </span>
              </h2>
              <p className="text-xs text-stone-500">
                Purohits located in or near your selected district for fast arrival and local tradition expertise.
              </p>
            </div>
          </div>

          {localPandits.length === 0 ? (
            <div className="bg-amber-50/70 border border-amber-200 rounded-2xl p-6 text-center space-y-2">
              <p className="text-sm font-semibold text-amber-900">
                No local pandits currently listed in {activeDistrictFilter} matching &ldquo;{searchQuery}&rdquo;.
              </p>
              <p className="text-xs text-stone-600">
                Check our verified Purohits from neighboring districts below who travel statewide!
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {localPandits.map((pandit) => (
                <PanditCard key={pandit.id} pandit={pandit} isLocal={true} />
              ))}
            </div>
          )}
        </div>

        {/* Tier 2: Other Districts Pandits */}
        {otherPandits.length > 0 && (
          <div>
            <div className="flex items-center justify-between mb-4 border-b border-stone-200 pb-2">
              <div>
                <h2 className="text-lg sm:text-xl font-bold font-serif text-stone-900 flex items-center gap-2">
                  <span className="text-stone-400">🌐</span>
                  <span>Verified Purohits from Other Odisha Districts</span>
                  <span className="text-xs bg-stone-100 text-stone-700 font-bold px-2 py-0.5 rounded-full">
                    {otherPandits.length} Available
                  </span>
                </h2>
                <p className="text-xs text-stone-500">
                  Renowned scholars and sevayats available for major pujas, Griha Pravesh, and Chandi Havan statewide.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {otherPandits.map((pandit) => (
                <PanditCard key={pandit.id} pandit={pandit} isLocal={false} />
              ))}
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

function PanditCard({ pandit, isLocal }: { pandit: PanditProfile; isLocal: boolean }) {
  const name = pandit.profiles?.full_name || 'Vedic Pandit Ji';
  const phone = pandit.profiles?.phone || '9437128910';

  return (
    <div
      className={`bg-white rounded-2xl border transition-all duration-300 overflow-hidden flex flex-col justify-between shadow-xs hover:shadow-lg ${
        isLocal
          ? 'border-orange-300 ring-1 ring-orange-200'
          : 'border-stone-200'
      }`}
    >
      <div className="p-5 space-y-4">
        {/* Top Badges */}
        <div className="flex items-center justify-between gap-2">
          {isLocal ? (
            <span className="inline-flex items-center gap-1 text-[11px] font-bold bg-emerald-100 text-emerald-800 px-2.5 py-0.5 rounded-full">
              <span>📍 Local to {pandit.district}</span>
            </span>
          ) : (
            <span className="text-[11px] font-semibold bg-stone-100 text-stone-700 px-2.5 py-0.5 rounded-full">
              📍 {pandit.district}
            </span>
          )}

          <div className="flex items-center gap-1 text-xs font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded-md border border-amber-200">
            <Star className="w-3.5 h-3.5 fill-amber-500 text-amber-500" />
            <span>{(pandit.rating || 4.9).toFixed(1)}</span>
          </div>
        </div>

        {/* Profile Info */}
        <div className="flex items-start gap-3.5">
          <div className="w-13 h-13 rounded-2xl bg-gradient-to-tr from-orange-600 via-amber-500 to-red-600 flex items-center justify-center text-white font-serif font-black text-xl shrink-0 shadow-md">
            🪔
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-1.5">
              <h3 className="font-bold font-serif text-stone-900 text-base truncate">
                {name}
              </h3>
              <span title="Verified Purohit">
                <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
              </span>
            </div>
            <p className="text-xs text-orange-800 font-semibold line-clamp-1">
              {pandit.vedic_qualification}
            </p>
            <p className="text-[11px] text-stone-500 mt-0.5">
              {pandit.city_town ? `${pandit.city_town}, ` : ''}{pandit.district}
            </p>
          </div>
        </div>

        {/* Meta badges */}
        <div className="grid grid-cols-2 gap-2 text-xs">
          <div className="bg-stone-50 rounded-lg p-2 border border-stone-100 flex items-center gap-1.5 text-stone-700">
            <Award className="w-3.5 h-3.5 text-orange-600 shrink-0" />
            <span className="font-medium text-[11px]">
              {pandit.experience_years} Yrs Experience
            </span>
          </div>

          <div className="bg-stone-50 rounded-lg p-2 border border-stone-100 flex items-center gap-1.5 text-stone-700">
            <Languages className="w-3.5 h-3.5 text-orange-600 shrink-0" />
            <span className="font-medium text-[11px] truncate">
              {(pandit.languages_spoken || ['Odia', 'Sanskrit']).join(', ')}
            </span>
          </div>
        </div>

        {/* Bio */}
        {pandit.bio && (
          <p className="text-xs text-stone-600 line-clamp-2 leading-relaxed">
            {pandit.bio}
          </p>
        )}
      </div>

      {/* Card Actions */}
      <div className="p-4 bg-stone-50 border-t border-stone-100 flex items-center gap-2">
        <a
          href={`tel:${phone}`}
          className="flex-1 py-2 px-3 bg-white hover:bg-stone-100 border border-stone-300 text-stone-800 rounded-xl text-xs font-bold text-center transition flex items-center justify-center gap-1.5 shadow-2xs"
        >
          <Phone className="w-3.5 h-3.5 text-emerald-600" />
          <span>Call Pandit</span>
        </a>

        <Link
          href="/"
          className="flex-1 py-2 px-3 bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-700 hover:to-red-700 text-white rounded-xl text-xs font-bold text-center transition flex items-center justify-center gap-1 shadow-md shadow-orange-600/20"
        >
          <span>Book Puja</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </Link>
      </div>
    </div>
  );
}
