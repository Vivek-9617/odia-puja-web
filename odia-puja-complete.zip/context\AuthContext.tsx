'use client';

import React, { createContext, useContext, useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { OdishaDistrict } from '@/types/database';
import type { User } from '@supabase/supabase-js';

export interface UserProfile {
  id: string;
  email?: string;
  full_name: string;
  phone: string;
  role: 'user' | 'pandit' | 'admin';
}

interface AuthContextType {
  user: User | null;
  profile: UserProfile | null;
  isLoading: boolean;
  selectedDistrict: OdishaDistrict;
  setSelectedDistrict: (district: OdishaDistrict) => void;
  isAuthModalOpen: boolean;
  authModalTab: 'login' | 'signup';
  openAuthModal: (tab?: 'login' | 'signup') => void;
  closeAuthModal: () => void;
  signOut: () => Promise<void>;
  setDemoUser: (role: 'user' | 'pandit' | 'admin') => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authModalTab, setAuthModalTab] = useState<'login' | 'signup'>('login');
  // Always default to 'Khordha (Bhubaneswar)' on initial render so server and client match
  const [selectedDistrict, setSelectedDistrictState] = useState<OdishaDistrict>('Khordha (Bhubaneswar)');

  // Safely restore localStorage after initial hydration mount
  useEffect(() => {
    try {
      const savedDistrict = localStorage.getItem('odiapuja_district') as OdishaDistrict;
      if (savedDistrict) {
        setSelectedDistrictState(savedDistrict);
      }
    } catch {}
  }, []);

  const setSelectedDistrict = (dist: OdishaDistrict) => {
    setSelectedDistrictState(dist);
    try {
      localStorage.setItem('odiapuja_district', dist);
    } catch {}
  };

  const fetchProfile = async (userId: string, email?: string) => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .single();

      if (data && !error) {
        setProfile({
          id: data.id,
          email: email || '',
          full_name: data.full_name || 'Odisha Devotee',
          phone: data.phone || '',
          role: data.role || 'user',
        });
      } else {
        setProfile({
          id: userId,
          email: email || '',
          full_name: email?.split('@')[0] || 'Devotee',
          phone: '',
          role: 'user',
        });
      }
    } catch {
      setProfile({
        id: userId,
        email: email || '',
        full_name: 'Devotee',
        phone: '',
        role: 'user',
      });
    }
  };

  useEffect(() => {
    let mounted = true;

    const getInitialSession = async () => {
      try {
        const { data: { session } } = await supabase.auth.getSession();
        if (!mounted) return;

        if (session?.user) {
          setUser(session.user);
          await fetchProfile(session.user.id, session.user.email);
        } else {
          const savedDemo = localStorage.getItem('odiapuja_demo_profile');
          if (savedDemo && mounted) {
            const parsed = JSON.parse(savedDemo);
            setProfile(parsed);
            setUser({ id: parsed.id, email: parsed.email } as unknown as User);
          }
        }
      } catch (e) {
        console.error('Error fetching auth session:', e);
      } finally {
        if (mounted) setIsLoading(false);
      }
    };

    getInitialSession();

    const { data: authListener } = supabase.auth.onAuthStateChange(
      async (_event, session) => {
        if (!mounted) return;

        if (session?.user) {
          setUser(session.user);
          await fetchProfile(session.user.id, session.user.email);
          localStorage.removeItem('odiapuja_demo_profile');
        } else {
          const savedDemo = localStorage.getItem('odiapuja_demo_profile');
          if (savedDemo && mounted) {
            const parsed = JSON.parse(savedDemo);
            setProfile(parsed);
            setUser({ id: parsed.id, email: parsed.email } as unknown as User);
          } else if (mounted) {
            setUser(null);
            setProfile(null);
          }
        }
        if (mounted) setIsLoading(false);
      }
    );

    return () => {
      mounted = false;
      authListener.subscription.unsubscribe();
    };
  }, []);

  const openAuthModal = (tab: 'login' | 'signup' = 'login') => {
    setAuthModalTab(tab);
    setIsAuthModalOpen(true);
  };

  const closeAuthModal = () => {
    setIsAuthModalOpen(false);
  };

  const signOut = async () => {
    try {
      await supabase.auth.signOut();
    } catch {}
    localStorage.removeItem('odiapuja_demo_profile');
    setUser(null);
    setProfile(null);
  };

  const setDemoUser = (role: 'user' | 'pandit' | 'admin') => {
    const demoProfile: UserProfile = {
      id:
        role === 'user'
          ? 'demo-user-123'
          : role === 'pandit'
          ? '1403b388-9d20-48ae-aced-8b8c05b1d967'
          : 'admin-master-001',
      email:
        role === 'user'
          ? 'devotee@odiapuja.in'
          : role === 'pandit'
          ? 'pandit.bhabani@gmail.com'
          : 'admin@odiapuja.in',
      full_name:
        role === 'user'
          ? 'Soumya Ranjan Mohapatra'
          : role === 'pandit'
          ? 'Pandit Bhabani Shankar Dash'
          : 'OdiaPuja Chief Administrator',
      phone:
        role === 'user'
          ? '9861234567'
          : role === 'pandit'
          ? '9437128910'
          : '9861012345',
      role,
    };
    setUser({ id: demoProfile.id, email: demoProfile.email } as unknown as User);
    setProfile(demoProfile);
    localStorage.setItem('odiapuja_demo_profile', JSON.stringify(demoProfile));
    closeAuthModal();
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        profile,
        isLoading,
        selectedDistrict,
        setSelectedDistrict,
        isAuthModalOpen,
        authModalTab,
        openAuthModal,
        closeAuthModal,
        signOut,
        setDemoUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
