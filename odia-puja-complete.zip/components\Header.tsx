'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { useAuth } from '@/context/AuthContext';
import { ODISHA_DISTRICTS } from '@/types/database';
import {
  MapPin,
  User,
  LogOut,
  ChevronDown,
  ShieldCheck,
  Menu,
  X,
  PlusCircle,
  Users
} from 'lucide-react';

export default function Header() {
  const {
    user,
    profile,
    selectedDistrict,
    setSelectedDistrict,
    openAuthModal,
    signOut,
  } = useAuth();

  const [mounted, setMounted] = useState(false);
  const [isDistrictDropdownOpen, setIsDistrictDropdownOpen] = useState(false);
  const [isProfileDropdownOpen, setIsProfileDropdownOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-orange-200 shadow-xs">
      {/* Top Auspicious Banner */}
      <div className="bg-gradient-to-r from-red-800 via-orange-700 to-amber-700 text-amber-100 text-[11px] py-1 px-4 text-center font-medium flex items-center justify-center gap-2">
        <span>🚩 ଜୟ ଜଗନ୍ନାଥ ସ୍ୱାମୀ ନୟନ ପଥଗାମୀ ଭବତୁ ମେ</span>
        <span className="hidden sm:inline">• Odisha&apos;s #1 Authentic Vedic Purohit &amp; Puja Booking Portal</span>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-3">
          {/* Logo & Platform Name */}
          <Link href="/" className="flex items-center gap-2.5 shrink-0 group">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-orange-600 via-amber-500 to-red-600 flex items-center justify-center shadow-md shadow-orange-500/20 text-white font-serif font-black text-xl group-hover:scale-105 transition">
              🪔
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xl md:text-2xl font-black font-serif tracking-tight text-stone-900">
                  Odia<span className="text-orange-600">Puja</span>
                </span>
                <span className="text-[10px] font-bold bg-orange-100 text-orange-800 px-1.5 py-0.5 rounded-sm">
                  ଓଡ଼ିଆ ପୂଜା
                </span>
              </div>
              <p className="text-[10px] text-stone-500 font-medium -mt-0.5 hidden sm:block">
                Odisha Pandit &amp; Puja Booking Platform
              </p>
            </div>
          </Link>

          {/* Flipkart-Style Odisha District Selector */}
          <div className="relative">
            <button
              onClick={() => setIsDistrictDropdownOpen(!isDistrictDropdownOpen)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-orange-50 hover:bg-orange-100 border border-orange-300 text-xs font-semibold text-stone-800 transition max-w-[200px] sm:max-w-xs truncate"
              title="Select your Odisha district"
            >
              <MapPin className="w-3.5 h-3.5 text-orange-600 shrink-0" />
              <span className="truncate" suppressHydrationWarning={true}>
                {mounted ? selectedDistrict : 'Khordha (Bhubaneswar)'}
              </span>
              <ChevronDown className="w-3.5 h-3.5 text-stone-500 shrink-0" />
            </button>

            {isDistrictDropdownOpen && (
              <div className="absolute left-0 mt-2 w-64 max-h-80 overflow-y-auto bg-white rounded-xl shadow-xl border border-orange-200 p-2 z-50">
                <div className="px-2 py-1.5 text-[11px] font-bold text-orange-900 uppercase tracking-wider border-b border-orange-100">
                  Select Odisha District (୩୦ ଜିଲ୍ଲା):
                </div>
                {ODISHA_DISTRICTS.map((district) => {
                  const isCurrent = mounted && selectedDistrict === district;
                  return (
                    <button
                      key={district}
                      onClick={() => {
                        setSelectedDistrict(district);
                        setIsDistrictDropdownOpen(false);
                      }}
                      className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs font-medium transition flex items-center justify-between ${
                        isCurrent
                          ? 'bg-orange-600 text-white font-semibold'
                          : 'text-stone-700 hover:bg-orange-50'
                      }`}
                    >
                      <span>{district}</span>
                      {isCurrent && (
                        <span className="text-[10px]">✓</span>
                      )}
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-5 text-sm font-semibold text-stone-700">
            <Link
              href="/"
              className="hover:text-orange-600 transition flex items-center gap-1"
            >
              Pujas (ପୂଜା)
            </Link>
            <Link
              href="/pandits"
              className="hover:text-orange-600 transition flex items-center gap-1"
            >
              <Users className="w-4 h-4 text-orange-600" />
              Pandits Directory
            </Link>
            <Link
              href="/pandit-register"
              className="hover:text-orange-600 transition flex items-center gap-1 text-amber-700"
            >
              <PlusCircle className="w-4 h-4 text-amber-600" />
              Register as Pandit
            </Link>
            <Link
              href="/admin"
              className="hover:text-orange-600 transition flex items-center gap-1 text-stone-600"
            >
              <ShieldCheck className="w-4 h-4 text-red-600" />
              Admin
            </Link>
          </nav>

          {/* Right Action: Login / User Profile */}
          <div className="flex items-center gap-2">
            {mounted && (profile || user) ? (
              <div className="relative">
                <button
                  onClick={() => setIsProfileDropdownOpen(!isProfileDropdownOpen)}
                  className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-stone-100 hover:bg-stone-200 border border-stone-300 text-xs font-semibold text-stone-800 transition"
                >
                  <div className="w-6 h-6 rounded-full bg-orange-600 text-white flex items-center justify-center font-bold text-xs">
                    {profile?.full_name?.charAt(0) || 'U'}
                  </div>
                  <span className="max-w-[100px] sm:max-w-xs truncate hidden sm:inline" suppressHydrationWarning={true}>
                    {profile?.full_name || 'My Profile'}
                  </span>
                  <ChevronDown className="w-3.5 h-3.5 text-stone-500" />
                </button>

                {isProfileDropdownOpen && (
                  <div className="absolute right-0 mt-2 w-52 bg-white rounded-xl shadow-xl border border-stone-200 p-2 z-50">
                    <div className="px-3 py-2 border-b border-stone-100 mb-1">
                      <div className="font-semibold text-xs text-stone-900 truncate">
                        {profile?.full_name}
                      </div>
                      <div className="text-[11px] text-stone-400 capitalize">
                        Role: {profile?.role || 'Devotee'}
                      </div>
                    </div>

                    <Link
                      href="/pandits"
                      onClick={() => setIsProfileDropdownOpen(false)}
                      className="w-full text-left px-3 py-2 rounded-lg text-xs font-medium text-stone-700 hover:bg-orange-50 flex items-center gap-2"
                    >
                      <Users className="w-3.5 h-3.5 text-orange-600" />
                      Browse Pandits
                    </Link>

                    <Link
                      href="/admin"
                      onClick={() => setIsProfileDropdownOpen(false)}
                      className="w-full text-left px-3 py-2 rounded-lg text-xs font-medium text-stone-700 hover:bg-orange-50 flex items-center gap-2"
                    >
                      <ShieldCheck className="w-3.5 h-3.5 text-red-600" />
                      Admin Dashboard
                    </Link>

                    <button
                      onClick={() => {
                        setIsProfileDropdownOpen(false);
                        signOut();
                      }}
                      className="w-full text-left px-3 py-2 rounded-lg text-xs font-medium text-red-600 hover:bg-red-50 flex items-center gap-2 mt-1 border-t border-stone-100"
                    >
                      <LogOut className="w-3.5 h-3.5" />
                      Sign Out
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <button
                onClick={() => openAuthModal('login')}
                className="px-4 py-2 bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-700 hover:to-red-700 text-white rounded-xl text-xs sm:text-sm font-bold shadow-md shadow-orange-600/20 transition flex items-center gap-1.5"
              >
                <User className="w-4 h-4" />
                <span>Login</span>
              </button>
            )}

            {/* Mobile Hamburger Menu Toggle */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="lg:hidden p-2 rounded-lg text-stone-700 hover:bg-orange-50"
              aria-label="Menu"
            >
              {isMobileMenuOpen ? (
                <X className="w-6 h-6" />
              ) : (
                <Menu className="w-6 h-6" />
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {isMobileMenuOpen && (
        <div className="lg:hidden border-t border-orange-200 bg-white px-4 py-4 space-y-3 shadow-lg animate-in slide-in-from-top duration-200">
          <Link
            href="/"
            onClick={() => setIsMobileMenuOpen(false)}
            className="block px-3 py-2 rounded-lg text-sm font-semibold text-stone-800 hover:bg-orange-50"
          >
            🪔 All Pujas (ପୂଜା ତାଲିକା)
          </Link>
          <Link
            href="/pandits"
            onClick={() => setIsMobileMenuOpen(false)}
            className="block px-3 py-2 rounded-lg text-sm font-semibold text-stone-800 hover:bg-orange-50"
          >
            👥 Pandits Directory (ପୁରୋହିତ ତାଲିକା)
          </Link>
          <Link
            href="/pandit-register"
            onClick={() => setIsMobileMenuOpen(false)}
            className="block px-3 py-2 rounded-lg text-sm font-semibold text-amber-800 hover:bg-amber-50"
          >
            ✍️ Register as Pandit Ji
          </Link>
          <Link
            href="/admin"
            onClick={() => setIsMobileMenuOpen(false)}
            className="block px-3 py-2 rounded-lg text-sm font-semibold text-red-700 hover:bg-red-50"
          >
            🛡️ Admin Dashboard
          </Link>
        </div>
      )}
    </header>
  );
}
