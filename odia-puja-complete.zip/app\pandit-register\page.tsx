'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/supabase';
import { ODISHA_DISTRICTS, OdishaDistrict } from '@/types/database';
import {
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  BookOpen,
  MapPin,
  Phone,
  User,
  Mail,
  Lock,
  ArrowRight
} from 'lucide-react';

const VEDIC_QUALIFICATIONS = [
  'Veda Shastri (Utkal Sanskrit University)',
  'Smarta Acharya (Mukti Mandap Affiliated, Puri)',
  'Rigveda Purohit (Utkaliya Parampara)',
  'Yajurveda Karma Kandi',
  'Samaveda Acharya',
  'Jyotirvid & Astro-Purohit',
  'Tantra & Chandi Homa Specialist',
  'Purohit with Hereditary / Kulaguru Parampara',
];

const AVAILABLE_LANGUAGES = [
  'Odia',
  'Sanskrit',
  'Hindi',
  'English',
  'Sambalpuri',
  'Bengali',
  'Telugu',
];

export default function PanditRegisterPage() {
  const { user, profile } = useAuth();

  const [fullName, setFullName] = useState(profile?.full_name || '');
  const [phone, setPhone] = useState(profile?.phone || '');
  const [email, setEmail] = useState(user?.email || '');
  const [password, setPassword] = useState('');
  const [qualification, setQualification] = useState(VEDIC_QUALIFICATIONS[0]);
  const [experienceYears, setExperienceYears] = useState(8);
  const [district, setDistrict] = useState<OdishaDistrict>('Khordha (Bhubaneswar)');
  const [cityTown, setCityTown] = useState('');
  const [bio, setBio] = useState('');
  const [languages, setLanguages] = useState<string[]>(['Odia', 'Sanskrit']);

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [isSuccess, setIsSuccess] = useState(false);

  const toggleLanguage = (lang: string) => {
    if (languages.includes(lang)) {
      if (languages.length > 1) {
        setLanguages(languages.filter((l) => l !== lang));
      }
    } else {
      setLanguages([...languages, lang]);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setErrorMessage('');

    try {
      let targetUserId = user?.id;

      // If user is not logged in, create an account first
      if (!targetUserId) {
        if (!email.trim() || !password.trim()) {
          throw new Error('Please provide an email and password to create your Pandit Ji account.');
        }

        const { data: authData, error: authError } = await supabase.auth.signUp({
          email: email.trim(),
          password: password,
          options: {
            data: {
              full_name: fullName.trim(),
              phone: phone.trim(),
              role: 'pandit',
            },
          },
        });

        if (authError) {
          throw authError;
        }

        targetUserId = authData.user?.id;
        if (!targetUserId) {
          throw new Error('Could not create user account. Please check your details.');
        }

        // Small timeout to allow profiles trigger to execute
        await new Promise((r) => setTimeout(r, 600));
      }

      // Ensure profile row exists
      const { data: existingProfile } = await supabase
        .from('profiles')
        .select('id')
        .eq('id', targetUserId)
        .single();

      if (!existingProfile) {
        await supabase.from('profiles').upsert([
          {
            id: targetUserId,
            full_name: fullName.trim(),
            phone: phone.trim(),
            role: 'pandit',
          },
        ]);
      }

      // Insert into pandit_profiles with is_verified: false
      const { error: panditError } = await supabase.from('pandit_profiles').upsert([
        {
          id: targetUserId,
          city_town: cityTown.trim(),
          vedic_qualification: qualification,
          experience_years: Number(experienceYears),
          languages_spoken: languages,
          district: district,
          bio: bio.trim() || `Certified ${qualification} serving devotees in ${district}.`,
          is_verified: false,
          is_available: true,
          rating: 5.0,
        },
      ]);

      if (panditError) {
        throw panditError;
      }

      setIsSuccess(true);
    } catch (err: unknown) {
      setErrorMessage((err as Error).message || 'Registration failed. Please verify your details.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-stone-50 py-10 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl mx-auto">
        {/* Breadcrumb / Back Link */}
        <div className="mb-6 flex items-center justify-between text-xs text-stone-500">
          <Link href="/" className="hover:text-orange-600 flex items-center gap-1 font-semibold">
            ← Back to Home
          </Link>
          <Link href="/pandits" className="text-orange-600 hover:underline font-semibold">
            View Verified Directory →
          </Link>
        </div>

        {isSuccess ? (
          /* Success Screen */
          <div className="bg-white rounded-3xl p-8 sm:p-12 shadow-xl border border-orange-200 text-center space-y-5 animate-in zoom-in-95 duration-200">
            <div className="w-20 h-20 bg-amber-100 text-amber-700 rounded-full flex items-center justify-center mx-auto shadow-inner">
              <CheckCircle2 className="w-10 h-10 text-orange-600" />
            </div>

            <div>
              <span className="text-xs font-bold uppercase tracking-widest text-orange-700">
                ପଞ୍ଜୀକରଣ ସଫଳ ହେଲା • Registration Received
              </span>
              <h2 className="text-2xl sm:text-3xl font-black font-serif text-stone-900 mt-1">
                Dhanyabad, Pandit Ji!
              </h2>
              <p className="text-sm text-stone-600 max-w-lg mx-auto mt-2 leading-relaxed">
                Your profile has been submitted with <span className="font-semibold text-amber-700">is_verified: false</span>. Our administrator will review your Vedic credentials and activate your profile.
              </p>
            </div>

            <div className="bg-amber-50 rounded-2xl p-4 border border-amber-200 max-w-md mx-auto text-xs text-left space-y-2">
              <div className="font-bold text-amber-900 flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-amber-700" />
                <span>Next Steps for Pandit Verification:</span>
              </div>
              <ul className="list-disc list-inside space-y-1 text-stone-700">
                <li>You can visit the <strong>Admin Dashboard</strong> to review and 1-click verify pending pandit profiles.</li>
                <li>Once verified, your profile will be ranked at the top for devotees booking pujas in <strong>{district}</strong>.</li>
              </ul>
            </div>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-3">
              <Link
                href="/admin"
                className="w-full sm:w-auto px-6 py-2.5 bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-700 hover:to-red-700 text-white font-bold rounded-xl text-xs shadow-md transition"
              >
                Go to Admin Dashboard to Verify
              </Link>
              <Link
                href="/pandits"
                className="w-full sm:w-auto px-6 py-2.5 bg-stone-100 hover:bg-stone-200 text-stone-800 font-bold rounded-xl text-xs transition border border-stone-300"
              >
                View Pandits Directory
              </Link>
            </div>
          </div>
        ) : (
          /* Registration Form */
          <div className="bg-white rounded-3xl shadow-xl border border-orange-200 overflow-hidden">
            {/* Header Banner */}
            <div className="bg-gradient-to-r from-orange-600 via-amber-600 to-red-700 text-white p-6 sm:p-8">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-xl">🪔</span>
                <span className="text-xs uppercase tracking-widest font-semibold text-orange-200">
                  ପୁରୋହିତ ପଞ୍ଜୀକରଣ • Vedic Purohit Onboarding
                </span>
              </div>
              <h1 className="text-2xl sm:text-4xl font-bold font-serif">
                Register as Certified Pandit Ji
              </h1>
              <p className="text-xs sm:text-sm text-orange-100 mt-2 max-w-2xl leading-relaxed">
                Join Odisha&apos;s most respected digital network of Purohits. Perform Vedic rituals with dignity, transparent dakshina, and devotees in your local district.
              </p>
            </div>

            <div className="p-6 sm:p-8">
              {errorMessage && (
                <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-xl text-xs text-red-700 flex items-start gap-2.5">
                  <AlertCircle className="w-5 h-5 shrink-0 text-red-600 mt-0.5" />
                  <div>
                    <strong className="font-bold">Error submitting registration:</strong>
                    <p className="mt-0.5">{errorMessage}</p>
                  </div>
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Personal & Contact Details */}
                <div>
                  <h3 className="text-sm font-bold uppercase tracking-wider text-orange-900 border-b border-orange-100 pb-2 mb-4 flex items-center gap-2">
                    <User className="w-4 h-4 text-orange-600" />
                    <span>Personal &amp; Contact Information</span>
                  </h3>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-stone-700 mb-1">
                        Full Name with Title (ପୂର୍ଣ୍ଣ ନାମ) *
                      </label>
                      <input
                        type="text"
                        required
                        value={fullName}
                        onChange={(e) => setFullName(e.target.value)}
                        placeholder="e.g. Pandit Debabrata Panigrahi"
                        className="w-full px-3 py-2 text-sm border border-stone-300 rounded-xl focus:ring-2 focus:ring-orange-500"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-stone-700 mb-1">
                        Contact Phone Number (ମୋବାଇଲ) *
                      </label>
                      <div className="relative">
                        <Phone className="w-4 h-4 text-stone-400 absolute left-3 top-2.5" />
                        <input
                          type="tel"
                          required
                          value={phone}
                          onChange={(e) => setPhone(e.target.value)}
                          placeholder="e.g. 9861044521"
                          className="w-full pl-9 pr-3 py-2 text-sm border border-stone-300 rounded-xl focus:ring-2 focus:ring-orange-500"
                        />
                      </div>
                    </div>

                    {!user && (
                      <>
                        <div>
                          <label className="block text-xs font-semibold text-stone-700 mb-1">
                            Email Address *
                          </label>
                          <div className="relative">
                            <Mail className="w-4 h-4 text-stone-400 absolute left-3 top-2.5" />
                            <input
                              type="email"
                              required
                              value={email}
                              onChange={(e) => setEmail(e.target.value)}
                              placeholder="pandit@gmail.com"
                              className="w-full pl-9 pr-3 py-2 text-sm border border-stone-300 rounded-xl focus:ring-2 focus:ring-orange-500"
                            />
                          </div>
                        </div>

                        <div>
                          <label className="block text-xs font-semibold text-stone-700 mb-1">
                            Set Account Password *
                          </label>
                          <div className="relative">
                            <Lock className="w-4 h-4 text-stone-400 absolute left-3 top-2.5" />
                            <input
                              type="password"
                              required
                              minLength={6}
                              value={password}
                              onChange={(e) => setPassword(e.target.value)}
                              placeholder="Minimum 6 characters"
                              className="w-full pl-9 pr-3 py-2 text-sm border border-stone-300 rounded-xl focus:ring-2 focus:ring-orange-500"
                            />
                          </div>
                        </div>
                      </>
                    )}
                  </div>
                </div>

                {/* Vedic Qualifications & Experience */}
                <div>
                  <h3 className="text-sm font-bold uppercase tracking-wider text-orange-900 border-b border-orange-100 pb-2 mb-4 flex items-center gap-2">
                    <BookOpen className="w-4 h-4 text-orange-600" />
                    <span>Vedic Qualifications &amp; Experience</span>
                  </h3>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-stone-700 mb-1">
                        Vedic Qualification / Parampara *
                      </label>
                      <select
                        value={qualification}
                        onChange={(e) => setQualification(e.target.value)}
                        className="w-full px-3 py-2 text-sm border border-stone-300 rounded-xl focus:ring-2 focus:ring-orange-500 bg-white"
                      >
                        {VEDIC_QUALIFICATIONS.map((q) => (
                          <option key={q} value={q}>
                            {q}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-stone-700 mb-1">
                        Years of Vedic Experience *
                      </label>
                      <input
                        type="number"
                        required
                        min={1}
                        max={60}
                        value={experienceYears}
                        onChange={(e) => setExperienceYears(Number(e.target.value))}
                        className="w-full px-3 py-2 text-sm border border-stone-300 rounded-xl focus:ring-2 focus:ring-orange-500"
                      />
                    </div>
                  </div>

                  {/* Languages Known */}
                  <div className="mt-4">
                    <label className="block text-xs font-semibold text-stone-700 mb-2">
                      Spoken Languages (ଭାଷା) *
                    </label>
                    <div className="flex flex-wrap gap-2">
                      {AVAILABLE_LANGUAGES.map((lang) => {
                        const isSelected = languages.includes(lang);
                        return (
                          <button
                            type="button"
                            key={lang}
                            onClick={() => toggleLanguage(lang)}
                            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition border ${
                              isSelected
                                ? 'bg-orange-600 text-white border-orange-600 shadow-xs'
                                : 'bg-stone-50 text-stone-700 border-stone-300 hover:bg-stone-100'
                            }`}
                          >
                            {isSelected ? '✓ ' : '+ '}
                            {lang}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </div>

                {/* Location & Bio */}
                <div>
                  <h3 className="text-sm font-bold uppercase tracking-wider text-orange-900 border-b border-orange-100 pb-2 mb-4 flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-orange-600" />
                    <span>Location &amp; District of Service</span>
                  </h3>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-semibold text-stone-700 mb-1">
                        Primary Odisha District (ଜିଲ୍ଲା) *
                      </label>
                      <select
                        value={district}
                        onChange={(e) => setDistrict(e.target.value as OdishaDistrict)}
                        className="w-full px-3 py-2 text-sm border border-stone-300 rounded-xl focus:ring-2 focus:ring-orange-500 bg-white"
                      >
                        {ODISHA_DISTRICTS.map((d) => (
                          <option key={d} value={d}>
                            {d}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-stone-700 mb-1">
                        City / Town / Locality *
                      </label>
                      <input
                        type="text"
                        required
                        value={cityTown}
                        onChange={(e) => setCityTown(e.target.value)}
                        placeholder="e.g. Badambadi / Nayapalli / Badadanda"
                        className="w-full px-3 py-2 text-sm border border-stone-300 rounded-xl focus:ring-2 focus:ring-orange-500"
                      />
                    </div>
                  </div>

                  <div className="mt-4">
                    <label className="block text-xs font-semibold text-stone-700 mb-1">
                      Brief Bio &amp; Ritual Specialization (ବିଶେଷଜ୍ଞତା)
                    </label>
                    <textarea
                      rows={3}
                      value={bio}
                      onChange={(e) => setBio(e.target.value)}
                      placeholder="Mention your specialized pujas (e.g., Satyanarayana Vrata, Vastu Shanti, Chandi Patha) and Gurukul/temple background..."
                      className="w-full p-3 text-sm border border-stone-300 rounded-xl focus:ring-2 focus:ring-orange-500 resize-none"
                    />
                  </div>
                </div>

                <div className="pt-4 border-t border-stone-200">
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full py-3.5 bg-gradient-to-r from-orange-600 via-amber-600 to-red-600 hover:from-orange-700 hover:to-red-700 text-white font-black rounded-xl text-sm sm:text-base shadow-lg transition flex items-center justify-center gap-2 disabled:opacity-50"
                  >
                    {isSubmitting ? (
                      'Submitting Registration...'
                    ) : (
                      <>
                        <span>Submit for Verification (ପଞ୍ଜୀକରଣ କରନ୍ତୁ)</span>
                        <ArrowRight className="w-5 h-5" />
                      </>
                    )}
                  </button>
                  <p className="text-[11px] text-center text-stone-400 mt-2">
                    Profiles are submitted with <code>is_verified: false</code> until reviewed by platform administrators.
                  </p>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
