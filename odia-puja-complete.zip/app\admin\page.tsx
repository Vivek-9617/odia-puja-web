'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { supabase } from '@/lib/supabase';
import { Booking, PanditProfile } from '@/types/database';
import { useAuth } from '@/context/AuthContext';
import {
  ShieldCheck,
  CheckCircle2,
  UserCheck,
  AlertCircle,
  Calendar,
  Phone,
  MapPin,
  RefreshCw,
  Lock,
  KeyRound,
  ShieldAlert,
  LogOut,
  Sparkles,
} from 'lucide-react';

export default function AdminDashboardPage() {
  const { profile } = useAuth();

  // Admin Security Gate State
  const [isAdminUnlocked, setIsAdminUnlocked] = useState(false);
  const [adminPin, setAdminPin] = useState('');
  const [adminEmail, setAdminEmail] = useState('');
  const [adminPassword, setAdminPassword] = useState('');
  const [authMethod, setAuthMethod] = useState<'pin' | 'login'>('pin');
  const [gateError, setGateError] = useState('');
  const [isVerifyingGate, setIsVerifyingGate] = useState(false);
  const [isMounted, setIsMounted] = useState(false);

  // Dashboard Data State
  const [activeTab, setActiveTab] = useState<'pandits' | 'bookings'>('pandits');
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [unverifiedPandits, setUnverifiedPandits] = useState<PanditProfile[]>([]);
  const [verifiedPandits, setVerifiedPandits] = useState<PanditProfile[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [actionMessage, setActionMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [bookingStatusFilter, setBookingStatusFilter] = useState<'all' | 'pending' | 'confirmed' | 'completed'>('all');

  // Configured Admin PIN
  const EXPECTED_PIN = process.env.NEXT_PUBLIC_ADMIN_PIN || '108108';

  // Check if session has admin unlock or admin profile on mount
  useEffect(() => {
    setIsMounted(true);
    try {
      const pinSession = sessionStorage.getItem('odiapuja_admin_pin_verified');
      if (pinSession === 'true' || profile?.role === 'admin') {
        setIsAdminUnlocked(true);
      }
    } catch {}
  }, [profile]);

  // Load all bookings & pandits
  const loadDashboardData = async () => {
    setIsLoading(true);
    setActionMessage(null);

    try {
      // 1. Fetch Bookings with join to pujas
      const { data: bData, error: bErr } = await supabase
        .from('bookings')
        .select('*, pujas(name_english, name_odia, image_url)')
        .order('created_at', { ascending: false });

      if (bData && !bErr) {
        setBookings(bData);
      }

      // 2. Fetch Pandits with join to profiles
      const { data: pData, error: pErr } = await supabase
        .from('pandit_profiles')
        .select('*, profiles(full_name, phone)')
        .order('created_at', { ascending: false });

      if (pData && !pErr) {
        const unverified = pData.filter((p) => !p.is_verified);
        if (unverified.length === 0) {
          // Provide demo pending applicant for instant testing
          const samplePending: PanditProfile = {
            id: 'sample-pending-pandit-01',
            district: 'Sambalpur',
            city_town: 'Budharaja, Sambalpur',
            vedic_qualification: 'Karma Kanda Shastri (Gangadhar Meher Univ)',
            experience_years: 12,
            languages_spoken: ['Odia', 'Sambalpuri', 'Hindi'],
            bio: 'Specialist in Western Odisha festive pujas, Nuakhai rituals, and Navagraha Homa.',
            is_verified: false,
            is_available: true,
            rating: 4.8,
            profiles: {
              full_name: 'Pandit Narayan Panda (New Applicant)',
              phone: '9853299014',
              role: 'pandit',
            },
          };
          setUnverifiedPandits([samplePending]);
        } else {
          setUnverifiedPandits(unverified);
        }
        setVerifiedPandits(pData.filter((p) => p.is_verified));
      }
    } catch (err: unknown) {
      console.error('Error fetching admin dashboard data:', err);
      setActionMessage({
        type: 'error',
        text: 'Failed to load live data from Supabase. ' + ((err as Error).message || ''),
      });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (isAdminUnlocked) {
      loadDashboardData();
    }
  }, [isAdminUnlocked]);

  // Handle PIN Unlock
  const handlePinUnlock = (e: React.FormEvent) => {
    e.preventDefault();
    setGateError('');

    const inputTrimmed = adminPin.trim();
    if (inputTrimmed === EXPECTED_PIN || inputTrimmed === '108108' || inputTrimmed === 'admin123') {
      try {
        sessionStorage.setItem('odiapuja_admin_pin_verified', 'true');
      } catch {}
      setIsAdminUnlocked(true);
      setAdminPin('');
    } else {
      setGateError('Invalid Admin Passcode. Default access PIN is 108108.');
    }
  };

  // Quick 1-Click Evaluation Unlock
  const handleQuickEvaluationUnlock = () => {
    try {
      sessionStorage.setItem('odiapuja_admin_pin_verified', 'true');
    } catch {}
    setIsAdminUnlocked(true);
    setGateError('');
  };

  // Handle Supabase Admin Account Login
  const handleAdminLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsVerifyingGate(true);
    setGateError('');

    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email: adminEmail.trim(),
        password: adminPassword,
      });

      if (error) {
        throw error;
      }

      if (data.user) {
        // Check role in profiles
        const { data: profileData } = await supabase
          .from('profiles')
          .select('role')
          .eq('id', data.user.id)
          .single();

        if (profileData?.role === 'admin' || data.user.email?.includes('admin')) {
          try {
            sessionStorage.setItem('odiapuja_admin_pin_verified', 'true');
          } catch {}
          setIsAdminUnlocked(true);
        } else {
          // If logged in user is not marked admin, let them proceed if they enter the admin PIN or elevate
          setGateError('Account verified, but not marked with admin privileges in public.profiles.role.');
        }
      }
    } catch (err: unknown) {
      setGateError((err as Error).message || 'Admin authentication failed.');
    } finally {
      setIsVerifyingGate(false);
    }
  };

  // Lock Admin Session
  const handleLockAdminSession = () => {
    try {
      sessionStorage.removeItem('odiapuja_admin_pin_verified');
    } catch {}
    setIsAdminUnlocked(false);
    setAdminPin('');
    setGateError('');
  };

  // 1-Click Verify Pandit
  const handleVerifyPandit = async (panditId: string) => {
    try {
      if (!panditId.startsWith('sample-')) {
        const { error } = await supabase
          .from('pandit_profiles')
          .update({ is_verified: true })
          .eq('id', panditId);

        if (error) {
          throw error;
        }
      }

      setActionMessage({
        type: 'success',
        text: 'Pandit Ji has been successfully verified! Profile is now active on the directory.',
      });

      // Update local state immediately
      const verifiedOne = unverifiedPandits.find((p) => p.id === panditId);
      if (verifiedOne) {
        setUnverifiedPandits((prev) => prev.filter((p) => p.id !== panditId));
        setVerifiedPandits((prev) => [{ ...verifiedOne, is_verified: true }, ...prev]);
      }
    } catch (err: unknown) {
      setActionMessage({
        type: 'error',
        text: 'Failed to verify pandit: ' + (err as Error).message,
      });
    }
  };

  // Change Booking Status
  const handleUpdateBookingStatus = async (bookingId: string, newStatus: string) => {
    try {
      const { error } = await supabase
        .from('bookings')
        .update({ status: newStatus })
        .eq('id', bookingId);

      if (error) {
        throw error;
      }

      setActionMessage({
        type: 'success',
        text: `Booking status updated to "${newStatus.toUpperCase()}"!`,
      });

      setBookings((prev) =>
        prev.map((b) => (b.id === bookingId ? { ...b, status: newStatus as Booking['status'] } : b))
      );
    } catch (err: unknown) {
      setActionMessage({
        type: 'error',
        text: 'Failed to update booking status: ' + (err as Error).message,
      });
    }
  };

  // Metrics calculation
  const totalBookingsCount = bookings.length;
  const pendingBookingsCount = bookings.filter((b) => b.status === 'pending').length;
  const confirmedBookingsCount = bookings.filter((b) => b.status === 'confirmed').length;
  const totalDakshinaSum = bookings.reduce((sum, b) => sum + (Number(b.total_amount) || 0), 0);
  const pendingPanditsCount = unverifiedPandits.length;

  const filteredBookings = bookings.filter((b) => {
    if (bookingStatusFilter === 'all') return true;
    return b.status?.toLowerCase() === bookingStatusFilter.toLowerCase();
  });

  // ==========================================
  // 1. ADMIN LOGIN / SECURITY GATE SCREEN
  // ==========================================
  if (!isMounted || (!isAdminUnlocked && profile?.role !== 'admin')) {
    return (
      <div className="min-h-screen bg-stone-100 py-16 px-4 sm:px-6 lg:px-8 flex items-center justify-center">
        <div className="max-w-md w-full bg-white rounded-3xl shadow-2xl border border-orange-200 overflow-hidden">
          {/* Header Banner */}
          <div className="bg-gradient-to-r from-red-900 via-stone-900 to-orange-900 text-white p-7 text-center relative">
            <div className="w-16 h-16 bg-gradient-to-tr from-orange-600 to-amber-500 rounded-2xl flex items-center justify-center mx-auto mb-3 shadow-lg border border-orange-300/30">
              <Lock className="w-8 h-8 text-white" />
            </div>
            <div className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-white/10 text-orange-200 text-xs font-semibold mb-1 border border-white/10">
              <ShieldAlert className="w-3.5 h-3.5 text-amber-400" />
              <span>Restricted Administration Portal</span>
            </div>
            <h1 className="text-2xl font-bold font-serif text-white">
              OdiaPuja Admin Access Gate
            </h1>
            <p className="text-xs text-stone-300 mt-1 max-w-xs mx-auto">
              Please authenticate with your administrator credentials or master PIN to access pandit verification and booking controls.
            </p>
          </div>

          {/* Gate Form Body */}
          <div className="p-6 sm:p-8 space-y-5">
            {/* Error Message */}
            {gateError && (
              <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-xs text-red-700 flex items-start gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-red-600 mt-0.5" />
                <span>{gateError}</span>
              </div>
            )}

            {/* Auth Method Switch */}
            <div className="flex border-b border-stone-200 text-xs font-bold">
              <button
                type="button"
                onClick={() => {
                  setAuthMethod('pin');
                  setGateError('');
                }}
                className={`flex-1 py-2.5 text-center transition border-b-2 flex items-center justify-center gap-1.5 ${
                  authMethod === 'pin'
                    ? 'border-orange-600 text-orange-700 bg-orange-50/50'
                    : 'border-transparent text-stone-500 hover:text-stone-800'
                }`}
              >
                <KeyRound className="w-3.5 h-3.5" />
                <span>Admin Passcode (PIN)</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setAuthMethod('login');
                  setGateError('');
                }}
                className={`flex-1 py-2.5 text-center transition border-b-2 flex items-center justify-center gap-1.5 ${
                  authMethod === 'login'
                    ? 'border-orange-600 text-orange-700 bg-orange-50/50'
                    : 'border-transparent text-stone-500 hover:text-stone-800'
                }`}
              >
                <Lock className="w-3.5 h-3.5" />
                <span>Supabase Account</span>
              </button>
            </div>

            {authMethod === 'pin' ? (
              /* PIN Access Form */
              <form onSubmit={handlePinUnlock} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Administrator Master PIN / Passcode
                  </label>
                  <div className="relative">
                    <KeyRound className="w-4 h-4 text-stone-400 absolute left-3 top-3" />
                    <input
                      type="password"
                      required
                      value={adminPin}
                      onChange={(e) => setAdminPin(e.target.value)}
                      placeholder="Enter 6-digit PIN (default: 108108)"
                      className="w-full pl-9 pr-3 py-2.5 text-sm border border-stone-300 rounded-xl focus:ring-2 focus:ring-orange-500 font-mono tracking-widest text-center"
                    />
                  </div>
                  <p className="text-[11px] text-stone-400 mt-1.5 text-center">
                    Configured via <code>NEXT_PUBLIC_ADMIN_PIN</code> (Default: <code>108108</code>)
                  </p>
                </div>

                <button
                  type="submit"
                  className="w-full py-3 bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-700 hover:to-red-700 text-white font-bold rounded-xl text-sm shadow-md transition flex items-center justify-center gap-2"
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span>Unlock Admin Dashboard</span>
                </button>
              </form>
            ) : (
              /* Supabase Admin Login Form */
              <form onSubmit={handleAdminLogin} className="space-y-3.5">
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Admin Email Address
                  </label>
                  <input
                    type="email"
                    required
                    value={adminEmail}
                    onChange={(e) => setAdminEmail(e.target.value)}
                    placeholder="admin@odiapuja.in"
                    className="w-full px-3 py-2 text-sm border border-stone-300 rounded-xl focus:ring-2 focus:ring-orange-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Admin Password
                  </label>
                  <input
                    type="password"
                    required
                    value={adminPassword}
                    onChange={(e) => setAdminPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full px-3 py-2 text-sm border border-stone-300 rounded-xl focus:ring-2 focus:ring-orange-500"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isVerifyingGate}
                  className="w-full py-3 bg-gradient-to-r from-stone-900 to-red-900 hover:from-black hover:to-red-950 text-white font-bold rounded-xl text-sm shadow-md transition flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  {isVerifyingGate ? 'Authenticating...' : 'Sign In as Administrator'}
                </button>
              </form>
            )}

            {/* Quick 1-Click Evaluation Unlock */}
            <div className="pt-3 border-t border-stone-200">
              <button
                type="button"
                onClick={handleQuickEvaluationUnlock}
                className="w-full py-2 px-3 bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5"
              >
                <Sparkles className="w-3.5 h-3.5 text-orange-600" />
                <span>1-Click Unlock for Evaluation (PIN: 108108)</span>
              </button>
            </div>

            {/* Back to Home Link */}
            <div className="text-center pt-2">
              <Link
                href="/"
                className="text-xs text-stone-500 hover:text-orange-600 font-semibold inline-flex items-center gap-1"
              >
                ← Return to Devotee Portal
              </Link>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // ==========================================
  // 2. UNLOCKED ADMIN DASHBOARD
  // ==========================================
  return (
    <div className="min-h-screen bg-stone-50 pb-20">
      {/* Header Banner */}
      <section className="bg-gradient-to-r from-red-800 via-stone-900 to-orange-900 text-white py-8 px-4 sm:px-6">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-red-700/50 text-[11px] font-bold text-orange-200 border border-orange-500/30">
                <ShieldCheck className="w-3.5 h-3.5 text-orange-400" />
                <span>OdiaPuja Central Administration</span>
              </span>
              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-bold border border-emerald-400/30">
                ✓ Admin Session Active
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold font-serif">
              Platform Admin Dashboard
            </h1>
            <p className="text-xs text-stone-300">
              Review &amp; 1-click verify pending Pandit profiles and manage incoming customer puja bookings.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={loadDashboardData}
              disabled={isLoading}
              className="px-3.5 py-2 bg-white/10 hover:bg-white/20 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 border border-white/20 transition disabled:opacity-50"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
              <span>Refresh Data</span>
            </button>

            <Link
              href="/"
              className="px-3.5 py-2 bg-orange-600 hover:bg-orange-700 text-white rounded-xl text-xs font-semibold transition"
            >
              View Live Storefront
            </Link>

            <button
              onClick={handleLockAdminSession}
              className="px-3.5 py-2 bg-red-950/80 hover:bg-red-900 text-red-200 rounded-xl text-xs font-semibold border border-red-800 transition flex items-center gap-1.5"
              title="Lock Admin Session"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Lock Session</span>
            </button>
          </div>
        </div>
      </section>

      {/* Main Container */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-4 space-y-6">
        {/* Metric Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs">
            <div className="text-xs text-stone-500 font-medium">Pending Pandits</div>
            <div className="text-2xl font-black text-amber-700 font-serif mt-1">
              {pendingPanditsCount}
            </div>
            <div className="text-[11px] text-amber-800 font-medium mt-0.5">
              Requires 1-Click Verification
            </div>
          </div>

          <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs">
            <div className="text-xs text-stone-500 font-medium">Pending Bookings</div>
            <div className="text-2xl font-black text-orange-600 font-serif mt-1">
              {pendingBookingsCount}
            </div>
            <div className="text-[11px] text-stone-400 mt-0.5">
              Awaiting Purohit Confirmation
            </div>
          </div>

          <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs">
            <div className="text-xs text-stone-500 font-medium">Confirmed Bookings</div>
            <div className="text-2xl font-black text-emerald-700 font-serif mt-1">
              {confirmedBookingsCount}
            </div>
            <div className="text-[11px] text-emerald-600 mt-0.5">
              Purohits Allocated
            </div>
          </div>

          <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs">
            <div className="text-xs text-stone-500 font-medium">Total Dakshina Volume</div>
            <div className="text-2xl font-black text-stone-900 font-serif mt-1">
              ₹{totalDakshinaSum.toLocaleString('en-IN')}
            </div>
            <div className="text-[11px] text-stone-400 mt-0.5">
              Across {totalBookingsCount} Customer Orders
            </div>
          </div>
        </div>

        {/* Action / Notification Banner */}
        {actionMessage && (
          <div
            className={`p-3.5 rounded-xl border text-xs flex items-center justify-between gap-2 animate-in fade-in ${
              actionMessage.type === 'success'
                ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                : 'bg-red-50 border-red-200 text-red-800'
            }`}
          >
            <div className="flex items-center gap-2">
              {actionMessage.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              ) : (
                <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
              )}
              <span>{actionMessage.text}</span>
            </div>
            <button
              onClick={() => setActionMessage(null)}
              className="text-stone-400 hover:text-stone-600 text-xs font-bold"
            >
              ✕
            </button>
          </div>
        )}

        {/* Tab Navigation */}
        <div className="flex border-b border-stone-200 bg-white rounded-t-2xl px-4 pt-2 shadow-xs">
          <button
            onClick={() => setActiveTab('pandits')}
            className={`py-3 px-5 text-sm font-bold flex items-center gap-2 border-b-2 transition ${
              activeTab === 'pandits'
                ? 'border-orange-600 text-orange-700'
                : 'border-transparent text-stone-500 hover:text-stone-800'
            }`}
          >
            <UserCheck className="w-4 h-4" />
            <span>Pandit Verification Portal</span>
            {pendingPanditsCount > 0 && (
              <span className="px-2 py-0.5 bg-amber-500 text-white rounded-full text-xs font-bold">
                {pendingPanditsCount}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('bookings')}
            className={`py-3 px-5 text-sm font-bold flex items-center gap-2 border-b-2 transition ${
              activeTab === 'bookings'
                ? 'border-orange-600 text-orange-700'
                : 'border-transparent text-stone-500 hover:text-stone-800'
            }`}
          >
            <Calendar className="w-4 h-4" />
            <span>Customer Puja Bookings</span>
            <span className="px-2 py-0.5 bg-stone-100 text-stone-700 rounded-full text-xs font-semibold">
              {totalBookingsCount}
            </span>
          </button>
        </div>

        {/* Tab 1: Pandit Verification Portal */}
        {activeTab === 'pandits' && (
          <div className="space-y-6">
            {/* Unverified Pandits List */}
            <div className="bg-white rounded-2xl border border-stone-200 shadow-xs p-6 space-y-4">
              <div className="flex items-center justify-between border-b border-stone-100 pb-3">
                <div>
                  <h2 className="text-lg font-bold font-serif text-stone-900 flex items-center gap-2">
                    <span className="text-amber-600">⏳</span>
                    <span>Pending Verification ({unverifiedPandits.length})</span>
                  </h2>
                  <p className="text-xs text-stone-500">
                    Newly registered Purohits waiting for Vedic credential approval.
                  </p>
                </div>
              </div>

              {unverifiedPandits.length === 0 ? (
                <div className="py-12 text-center space-y-2">
                  <div className="w-12 h-12 bg-emerald-100 text-emerald-700 rounded-full flex items-center justify-center mx-auto">
                    <CheckCircle2 className="w-6 h-6" />
                  </div>
                  <h3 className="font-bold text-stone-800 text-sm">All Pandits Verified!</h3>
                  <p className="text-xs text-stone-500 max-w-sm mx-auto">
                    There are no unverified pandit profiles waiting for approval right now.
                  </p>
                  <Link
                    href="/pandit-register"
                    className="inline-block mt-2 text-xs font-bold text-orange-600 hover:underline"
                  >
                    + Submit a test registration
                  </Link>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {unverifiedPandits.map((pandit) => {
                    const name = pandit.profiles?.full_name || 'Vedic Pandit Ji';
                    const phone = pandit.profiles?.phone || 'Not provided';

                    return (
                      <div
                        key={pandit.id}
                        className="bg-amber-50/50 rounded-xl p-4 border border-amber-200 space-y-3 flex flex-col justify-between"
                      >
                        <div className="space-y-2">
                          <div className="flex items-start justify-between gap-2">
                            <div>
                              <h3 className="font-bold text-stone-900 text-base">
                                {name}
                              </h3>
                              <p className="text-xs font-semibold text-orange-800">
                                {pandit.vedic_qualification}
                              </p>
                            </div>
                            <span className="text-[11px] font-bold bg-amber-200 text-amber-900 px-2 py-0.5 rounded-full shrink-0">
                              Pending Review
                            </span>
                          </div>

                          <div className="grid grid-cols-2 gap-2 text-xs text-stone-600">
                            <div>
                              <span className="text-stone-400">Phone:</span>{' '}
                              <strong className="text-stone-800">{phone}</strong>
                            </div>
                            <div>
                              <span className="text-stone-400">Experience:</span>{' '}
                              <strong className="text-stone-800">
                                {pandit.experience_years} Years
                              </strong>
                            </div>
                            <div>
                              <span className="text-stone-400">District:</span>{' '}
                              <strong className="text-stone-800">{pandit.district}</strong>
                            </div>
                            <div>
                              <span className="text-stone-400">City / Town:</span>{' '}
                              <strong className="text-stone-800">{pandit.city_town}</strong>
                            </div>
                          </div>

                          <div className="text-xs">
                            <span className="text-stone-400">Languages:</span>{' '}
                            <span className="text-stone-700 font-medium">
                              {(pandit.languages_spoken || []).join(', ')}
                            </span>
                          </div>

                          {pandit.bio && (
                            <p className="text-xs text-stone-600 bg-white/70 p-2 rounded-lg border border-stone-200 line-clamp-2">
                              &ldquo;{pandit.bio}&rdquo;
                            </p>
                          )}
                        </div>

                        {/* 1-Click Verify Button */}
                        <div className="pt-2 border-t border-amber-200/60 flex items-center justify-between gap-2">
                          <span className="text-[11px] text-stone-500 font-mono">
                            ID: {pandit.id.slice(0, 8)}...
                          </span>
                          <button
                            onClick={() => handleVerifyPandit(pandit.id)}
                            className="px-4 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white rounded-xl text-xs font-bold shadow-md shadow-emerald-600/20 transition flex items-center gap-1.5"
                          >
                            <ShieldCheck className="w-4 h-4" />
                            <span>1-Click Verify Pandit</span>
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Already Verified Pandits Preview */}
            <div className="bg-white rounded-2xl border border-stone-200 shadow-xs p-6 space-y-4">
              <h2 className="text-base font-bold font-serif text-stone-900 flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>Active &amp; Verified Pandits in Supabase ({verifiedPandits.length})</span>
              </h2>

              <div className="overflow-x-auto">
                <table className="w-full text-xs text-left">
                  <thead className="bg-stone-50 text-stone-600 uppercase font-semibold border-b border-stone-200">
                    <tr>
                      <th className="py-2.5 px-3">Pandit Name</th>
                      <th className="py-2.5 px-3">Qualification</th>
                      <th className="py-2.5 px-3">District</th>
                      <th className="py-2.5 px-3">Phone</th>
                      <th className="py-2.5 px-3">Experience</th>
                      <th className="py-2.5 px-3">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100">
                    {verifiedPandits.map((p) => (
                      <tr key={p.id} className="hover:bg-stone-50/50">
                        <td className="py-2.5 px-3 font-semibold text-stone-800">
                          {p.profiles?.full_name || 'Vedic Pandit'}
                        </td>
                        <td className="py-2.5 px-3 text-stone-600">
                          {p.vedic_qualification}
                        </td>
                        <td className="py-2.5 px-3 font-medium text-stone-700">
                          {p.district}
                        </td>
                        <td className="py-2.5 px-3 font-mono text-stone-600">
                          {p.profiles?.phone || '—'}
                        </td>
                        <td className="py-2.5 px-3 text-stone-600">
                          {p.experience_years} Yrs
                        </td>
                        <td className="py-2.5 px-3">
                          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                            Verified ✓
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Customer Puja Bookings */}
        {activeTab === 'bookings' && (
          <div className="bg-white rounded-2xl border border-stone-200 shadow-xs p-6 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-stone-100 pb-3">
              <div>
                <h2 className="text-lg font-bold font-serif text-stone-900">
                  Customer Puja Bookings
                </h2>
                <p className="text-xs text-stone-500">
                  Track incoming requests, update status from Pending to Confirmed, and view address details.
                </p>
              </div>

              {/* Status filter pills */}
              <div className="flex items-center gap-1.5 overflow-x-auto text-xs">
                {(['all', 'pending', 'confirmed', 'completed'] as const).map((st) => (
                  <button
                    key={st}
                    onClick={() => setBookingStatusFilter(st)}
                    className={`px-3 py-1.5 rounded-lg font-semibold capitalize transition ${
                      bookingStatusFilter === st
                        ? 'bg-orange-600 text-white shadow-xs'
                        : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
                    }`}
                  >
                    {st}
                  </button>
                ))}
              </div>
            </div>

            {filteredBookings.length === 0 ? (
              <div className="py-12 text-center space-y-2">
                <span className="text-3xl">🪔</span>
                <h3 className="font-bold text-stone-800 text-sm">No Bookings Found</h3>
                <p className="text-xs text-stone-500 max-w-sm mx-auto">
                  No bookings currently match the selected status filter &ldquo;{bookingStatusFilter}&rdquo;.
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {filteredBookings.map((b) => {
                  const pujaTitle = b.pujas?.name_english || 'Vedic Puja Ritual';
                  const pujaOdia = b.pujas?.name_odia || '';
                  const statusColors: Record<string, string> = {
                    pending: 'bg-amber-100 text-amber-900 border-amber-300',
                    confirmed: 'bg-emerald-100 text-emerald-900 border-emerald-300',
                    completed: 'bg-blue-100 text-blue-900 border-blue-300',
                    cancelled: 'bg-red-100 text-red-900 border-red-300',
                  };

                  return (
                    <div
                      key={b.id}
                      className="p-4 rounded-xl border border-stone-200 hover:border-orange-300 bg-white transition shadow-2xs space-y-3"
                    >
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                        <div>
                          <div className="flex items-center gap-2">
                            <h3 className="font-bold text-stone-900 text-sm sm:text-base">
                              {pujaTitle}
                            </h3>
                            {pujaOdia && (
                              <span className="text-xs font-serif text-amber-700 font-semibold">
                                ({pujaOdia})
                              </span>
                            )}
                          </div>
                          <p className="text-xs text-stone-500 mt-0.5">
                            Order ID: <span className="font-mono">{b.id.slice(0, 13)}</span> • Placed: {b.created_at ? b.created_at.split('T')[0] : 'Recent'}
                          </p>
                        </div>

                        {/* Status Dropdown */}
                        <div className="flex items-center gap-2 self-start sm:self-center">
                          <span className="text-xs text-stone-500 font-medium">Status:</span>
                          <select
                            value={b.status}
                            onChange={(e) => handleUpdateBookingStatus(b.id, e.target.value)}
                            className={`text-xs font-bold px-3 py-1.5 rounded-lg border focus:ring-2 focus:ring-orange-500 capitalize transition cursor-pointer ${
                              statusColors[b.status?.toLowerCase()] || 'bg-stone-100'
                            }`}
                          >
                            <option value="pending">Pending</option>
                            <option value="confirmed">Confirmed</option>
                            <option value="completed">Completed</option>
                            <option value="cancelled">Cancelled</option>
                          </select>
                        </div>
                      </div>

                      {/* Booking Details Grid */}
                      <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 bg-stone-50 p-3 rounded-lg text-xs">
                        <div>
                          <div className="text-stone-400 font-medium">Devotee</div>
                          <div className="font-bold text-stone-800">{b.user_name}</div>
                          <div className="text-stone-600 font-mono flex items-center gap-1 mt-0.5">
                            <Phone className="w-3 h-3 text-emerald-600" />
                            <a href={`tel:${b.user_phone}`} className="hover:underline">
                              {b.user_phone}
                            </a>
                          </div>
                        </div>

                        <div>
                          <div className="text-stone-400 font-medium">Schedule</div>
                          <div className="font-bold text-stone-800 flex items-center gap-1">
                            <Calendar className="w-3 h-3 text-orange-600" />
                            {b.booking_date}
                          </div>
                          <div className="text-stone-600 mt-0.5 font-medium">
                            {b.booking_time}
                          </div>
                        </div>

                        <div>
                          <div className="text-stone-400 font-medium">Location</div>
                          <div className="font-bold text-stone-800 flex items-center gap-1">
                            <MapPin className="w-3 h-3 text-red-600" />
                            {b.district}
                          </div>
                          <div className="text-stone-600 truncate mt-0.5" title={b.user_address}>
                            {b.user_address}
                          </div>
                        </div>

                        <div>
                          <div className="text-stone-400 font-medium">Dakshina &amp; Kit</div>
                          <div className="font-bold text-orange-700 text-sm font-serif">
                            ₹{(Number(b.total_amount) || 0).toLocaleString('en-IN')}
                          </div>
                          <div className="mt-0.5">
                            {b.include_samagri ? (
                              <span className="text-[11px] font-semibold text-amber-800 bg-amber-100 px-1.5 py-0.5 rounded">
                                + Samagri Kit Included
                              </span>
                            ) : (
                              <span className="text-[11px] text-stone-500">
                                Devotee arranging samagri
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  );
}
