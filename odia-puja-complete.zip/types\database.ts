export interface SamagriItem {
  item: string;
  qty: string;
}

export interface Puja {
  id: string;
  name_odia: string;
  name_english: string;
  category: 'Odisha Special' | 'Griha Pravesh' | 'Festivals' | string;
  description: string;
  duration_hours: number;
  base_dakshina: number;
  samagri_list: SamagriItem[];
  image_url: string;
  is_active: boolean;
}

export interface PanditProfile {
  id: string;
  city_town: string;
  vedic_qualification: string;
  experience_years: number;
  languages_spoken: string[];
  district: string;
  bio: string;
  pincode?: string | null;
  is_verified: boolean;
  is_available: boolean;
  rating: number;
  created_at?: string;
  profiles?: {
    full_name: string;
    phone: string;
    role?: string;
  };
}

export interface Booking {
  id: string;
  user_id?: string | null;
  puja_id: string;
  pandit_id?: string | null;
  booking_date: string;
  booking_time: string;
  user_name: string;
  user_phone: string;
  user_address: string;
  district: string;
  include_samagri: boolean;
  total_amount: number;
  status: 'pending' | 'confirmed' | 'completed' | 'cancelled';
  created_at?: string;
  pujas?: {
    name_english: string;
    name_odia: string;
    image_url: string;
    duration_hours?: number;
  };
}

export const ODISHA_DISTRICTS = [
  'Khordha (Bhubaneswar)',
  'Cuttack',
  'Puri',
  'Ganjam',
  'Sambalpur',
  'Balasore',
  'Mayurbhanj',
  'Bhadrak',
  'Jajpur',
  'Kendrapara',
  'Jagatsinghpur',
  'Angul',
  'Dhenkanal',
  'Bargarh',
  'Bolangir',
  'Sundergarh (Rourkela)',
  'Koraput',
  'Rayagada',
  'Kalahandi',
  'Jharsuguda',
  'Keonjhar',
  'Nayagarh',
  'Nabarangpur',
  'Nuapada',
  'Kandhamal',
  'Boudh',
  'Subarnapur (Sonepur)',
  'Deogarh',
  'Malkangiri',
  'Gajapati'
] as const;

export type OdishaDistrict = (typeof ODISHA_DISTRICTS)[number];

export const PUJA_CATEGORIES = [
  'All',
  'Odisha Special',
  'Griha Pravesh',
  'Festivals'
] as const;

export const MUHURAT_SLOTS = [
  { time: '05:30 AM', label: 'Brahma Muhurat (ପ୍ରାତଃ ବ୍ରାହ୍ମ ମୁହୂର୍ତ୍ତ)' },
  { time: '07:00 AM', label: 'Pratah Kaala (ପ୍ରାତଃ କାଳ - ଶୁଭ ବେଳା)' },
  { time: '09:30 AM', label: 'Abhijit Muhurat (ଅଭିଜିତ ମୁହୂର୍ତ୍ତ - ସର୍ବଶ୍ରେଷ୍ଠ)' },
  { time: '11:30 AM', label: 'Madhyanha Kaala (ମଧ୍ୟାହ୍ନ ଶୁଭ ବେଳା)' },
  { time: '04:30 PM', label: 'Godhuli Lagna (ଗୋଧୂଳି ଲଗ୍ନ - ସାୟଂକାଳ)' },
  { time: '06:30 PM', label: 'Sandhya Arati Kaala (ସନ୍ଧ୍ୟା ଆଳତି କାଳ)' }
];

